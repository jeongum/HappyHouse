package com.ssafy.happyhouse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HappyhouseSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
