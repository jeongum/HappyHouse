var mapContainer = document.getElementById('map'), // 지도를 표시할 div  
mapOption = { 
	center: new kakao.maps.LatLng(37.566826, 126.9786567), // 지도의 중심좌표
	level: 3 // 지도의 확대 레벨
};

var map = new kakao.maps.Map(mapContainer, mapOption); // 지도를 생성합니다

// 마커 이미지의 이미지 주소입니다
var imageSrc = "https://t1.daumcdn.net/localimg/localimages/07/mapapidoc/markerStar.png"; 

function displayMarkers(places){
	for (var i = 0; i < places.length; i ++) {
	    
	    // 마커 이미지의 이미지 크기 입니다
	    var imageSize = new kakao.maps.Size(24, 35); 
	    
	    // 마커 이미지를 생성합니다    
	    var markerImage = new kakao.maps.MarkerImage(imageSrc, imageSize); 
	    
	    // 마커를 생성합니다
	    var marker = new kakao.maps.Marker({
	        map: map, // 마커를 표시할 지도
	        position: new kakao.maps.LatLng(places[i].lat, places[i].lng), // 마커를 표시할 위치
	        title : places[i].place, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
	        image : markerImage // 마커 이미지 
	    });
	    
	    var overlay = new kakao.maps.InfoWindow({
	        content: infoContent(places[i]) // 인포윈도우에 표시할 내용
	    });
	    
	    (function(marker, overlay) {
	        // 마커에 mouseover 이벤트를 등록하고 마우스 오버 시 인포윈도우를 표시합니다 
	        kakao.maps.event.addListener(marker, 'mouseover', function() {
	        	overlay.open(map, marker);
	        });

	        // 마커에 mouseout 이벤트를 등록하고 마우스 아웃 시 인포윈도우를 닫습니다
	        kakao.maps.event.addListener(marker, 'mouseout', function() {
	        	overlay.close();
	        });
	    })(marker, overlay);
	}
	
}


function infoContent(info){
	return '<div class="wrap">' + 
    '    <div class="info">' + 
    '        <div class="title">' + 
                info.place + 
    '        </div>' + 
    '        <div class="body">' + 
    '            <div class="desc">' + 
    '                <div class="ellipsis">'+info.address+'</div>' + 
    '                <div class="jibun ellipsis"> LCD '+info.lcdCnt+'개 </div>' + 
    '                <div class="jibun ellipsis"> QR '+info.qrCnt+'개 </div>' + 
    '            </div>' + 
    '        </div>' + 
    '    </div>' +    
    '</div>';
}

function panTo(data) {
    // 이동할 위도 경도 위치를 생성합니다 
    var moveLatLon = new kakao.maps.LatLng(data[0].lat, data[0].lng);
    
    // 지도 중심을 부드럽게 이동시킵니다
    // 만약 이동할 거리가 지도 화면보다 크면 부드러운 효과 없이 이동합니다
    map.panTo(moveLatLon);            
}   
