package com.ssafy.happyhouse.controller;

import java.net.URI;
import java.net.URLEncoder;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.ssafy.happyhouse.model.dto.HouseInfo;
import com.ssafy.happyhouse.model.dto.SidoGugunCode;
import com.ssafy.happyhouse.model.service.HappyHouseMapService;

@RestController
@RequestMapping("/map")
public class HappyHouseMapController {
	
	private final Logger logger = LoggerFactory.getLogger(HappyHouseMapController.class);
	
	
	@Autowired
	public HappyHouseMapService happyHouseMapService;
	
	@GetMapping("/sido")
	public ResponseEntity<List<SidoGugunCode>> sido() throws Exception{
		return new ResponseEntity<List<SidoGugunCode>>(happyHouseMapService.getSido(), HttpStatus.OK);
	}

	@GetMapping("/gugun")
	public ResponseEntity<List<SidoGugunCode>> gugun(@RequestParam("sido") String sido) throws Exception{
		logger.info("gugun - 호출");
		return new ResponseEntity<List<SidoGugunCode>>(happyHouseMapService.getGugunInSido(sido), HttpStatus.OK);
	}

	@GetMapping("/dong")
	public ResponseEntity<List<HouseInfo>> dong(@RequestParam("gugun") String gugun) throws Exception{
		return new ResponseEntity<List<HouseInfo>>(happyHouseMapService.getDongInGugun(gugun), HttpStatus.OK);
	}

	@GetMapping("/apt")
	public ResponseEntity<String> apt(@RequestParam("gugunCode") String gugunCode) throws Exception{
		MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
		StringBuilder urlBuilder = new StringBuilder("http://openapi.molit.go.kr/OpenAPI_ToolInstallPackage/service/rest/RTMSOBJSvc/getRTMSDataSvcAptTradeDev"); /*URL*/
		urlBuilder.append("?" + URLEncoder.encode("serviceKey","UTF-8") + "=Amf9JPnyYWX2qetXZUtx9APCh00EKfsho%2BKIuvAg8xPjHKQsUDWS6eq8EYS6DsLAvnpb%2BvG110d7rNSzFmPr8w%3D%3D"); /*Service Key*/
		urlBuilder.append("&" + URLEncoder.encode("LAWD_CD","UTF-8") + "=" + URLEncoder.encode(gugunCode, "UTF-8")); /*지역코드*/
		urlBuilder.append("&" + URLEncoder.encode("DEAL_YMD","UTF-8") + "=" + URLEncoder.encode("202110", "UTF-8")); /*계약월*/

		HttpHeaders headers = new HttpHeaders();
		headers.set("Accept", "application/json");
		
		HttpEntity<MultiValueMap<String, String>> entity = new HttpEntity<>(params, headers);
		
		RestTemplate rt = new RestTemplate();
		return rt.exchange(
				new URI(urlBuilder.toString()), //{요청할 서버 주소}
                HttpMethod.GET, //{요청할 방식}
                null, // {요청할 때 보낼 데이터}
                String.class 
			);
	}

	@GetMapping("/aptName")
	public ResponseEntity<List<HouseInfo>> aptName(@RequestParam("aptName") String aptName) throws Exception{
		return new ResponseEntity<List<HouseInfo>>(happyHouseMapService.getAptInName('%'+aptName+'%'), HttpStatus.OK);
	}
	
	@GetMapping("/favoriteName")
	public ResponseEntity<List<String>> favoriteName(@RequestParam("sido") String sido,@RequestParam("gugun") String gugun) throws Exception{
		return new ResponseEntity<List<String>>(happyHouseMapService.getFavoriteName(sido, gugun), HttpStatus.OK);
	}
}
