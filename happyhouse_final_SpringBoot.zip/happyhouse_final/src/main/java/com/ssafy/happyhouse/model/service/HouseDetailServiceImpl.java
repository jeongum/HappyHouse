package com.ssafy.happyhouse.model.service;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.happyhouse.model.dto.AptRealPrc;
import com.ssafy.happyhouse.model.repo.HouseDetailRepo;

@Service
public class HouseDetailServiceImpl implements HouseDetailService {

	@Autowired
	HouseDetailRepo repo;
	
	@Override
	public List<AptRealPrc> getRealPrice(String regionCd) throws SQLException {
		return repo.getRealPrice(regionCd);
	}

}
