package com.ssafy.happyhouse.model.service;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.happyhouse.model.dto.NoticeDto;
import com.ssafy.happyhouse.model.repo.NoticeMapper;

@Service
public class NoticeServiceImpl implements NoticeService {
	@Autowired
	private SqlSession sqlSession;
	
	@Override
	public void registerNotice(NoticeDto noticeDto) throws Exception {
		sqlSession.getMapper(NoticeMapper.class).registerNotice(noticeDto);
	}

	@Override
	public List<NoticeDto> listNotice() throws Exception {
		return sqlSession.getMapper(NoticeMapper.class).listNotice();
	}

	@Override
	public NoticeDto getNotice(int noticeno) throws Exception {
		return sqlSession.getMapper(NoticeMapper.class).getNotice(noticeno);
	}

	@Override
	public void updateNotice(NoticeDto noticeDto) throws Exception {
		sqlSession.getMapper(NoticeMapper.class).updateNotice(noticeDto);
		
	}

	@Override
	public void deleteNotice(int noticeno) throws Exception {
		sqlSession.getMapper(NoticeMapper.class).deleteNotice(noticeno);
	}

}
