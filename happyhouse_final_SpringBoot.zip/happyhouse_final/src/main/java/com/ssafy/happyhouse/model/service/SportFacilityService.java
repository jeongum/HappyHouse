package com.ssafy.happyhouse.model.service;

import java.sql.SQLException;
import java.util.List;

import com.ssafy.happyhouse.model.dto.SportFacilityDto;

public interface SportFacilityService {
	List<SportFacilityDto> getSportFacility() throws SQLException;
}
