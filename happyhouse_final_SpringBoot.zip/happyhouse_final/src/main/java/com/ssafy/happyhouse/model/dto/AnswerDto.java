package com.ssafy.happyhouse.model.dto;

public class AnswerDto {
	private int answer_no;
	private String answer;
	private String answer_time;
	private int question_no;
	private String username;

	public int getAnswer_no() {
		return answer_no;
	}
	public void setAnswer_no(int answer_no) {
		this.answer_no = answer_no;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	
	public String getAnswer_time() {
		return answer_time;
	}
	public void setAnswer_time(String answer_time) {
		this.answer_time = answer_time;
	}
	public int getQuestion_no() {
		return question_no;
	}
	public void setQuestion_no(int question_no) {
		this.question_no = question_no;
	}
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	@Override
	public String toString() {
		return "AnswerDto [answer_no=" + answer_no + ", answer=" + answer + ", answer_time=" + answer_time
				+ ", question_no=" + question_no + ", username=" + username + "]";
	}
	
	
	
}
