package com.ssafy.happyhouse.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.happyhouse.model.dto.AnswerDto;
import com.ssafy.happyhouse.model.repo.AnswerRepo;

@Service
public class AnswerServiceImpl implements AnswerService {
	@Autowired
	private AnswerRepo repo;
	
	@Override
	public List<AnswerDto> list(int question_no) {
		return repo.list(question_no);
	}

	@Override
	public boolean create(AnswerDto answerDto) {
		return repo.create(answerDto)==1;
	}

	@Override
	public boolean modify(AnswerDto answerDto) {
		return repo.modify(answerDto)==1;
	}

	@Override
	public boolean delete(int answer_no) {
		return repo.delete(answer_no)==1;
	}

}
