package com.ssafy.happyhouse.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ssafy.happyhouse.model.dto.MemberDto;
import com.ssafy.happyhouse.model.service.MemberService;


@Controller
@RequestMapping("/user")
public class MemberController {
	
	@Autowired
	private MemberService memberService;
	
	@GetMapping("/signup")
	public String signup() {
		return "user/signup";
	}
	
	@PostMapping("/register")
	public String register(MemberDto memberDto, Model model) throws Exception {
		System.out.println(memberDto);
		
		memberService.registerMember(memberDto);
		return "redirect:/";
	}
	

	@GetMapping("/logout")
	public String logout(HttpSession session) {
		session.invalidate();
		return "redirect:/";
	}
	
	@GetMapping("/mypage")
	public String mypage() {
		return "user/MyPage";
	}
	
	@GetMapping("/modify")
	public String modify() {
		return "user/signup_update";
	}
	
	@PostMapping("/modify")
	public String modify(MemberDto memberDto) throws Exception {
		System.out.println("수정 컨트롤러 "+memberDto);
		memberService.updateMember(memberDto);
		return "redirect:/";
	}
	
	
	@PostMapping("/delete")
	public String Delete(String userId) throws Exception {
		//System.out.println("삭제 컨트롤러 아이디 : "+userId);
		memberService.deleteMember(userId);
		return "redirect:/user/logout";
	}
	
	@GetMapping("/list")
	public String list() {
		return "user/list";
	}
}
