package com.ssafy.happyhouse.model.service;

import java.util.List;

import com.ssafy.happyhouse.model.dto.NoticeDto;

public interface NoticeService {
	
	void registerNotice(NoticeDto noticeDto) throws Exception;
	
	List<NoticeDto> listNotice() throws Exception;
	
	NoticeDto getNotice(int noticeno) throws Exception;
	
	void updateNotice(NoticeDto noticeDto) throws Exception;
	
	void deleteNotice(int noticeno) throws Exception;
	
	
}
