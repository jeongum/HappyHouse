package com.ssafy.happyhouse.model.service;

import java.util.List;

import com.ssafy.happyhouse.model.dto.AnswerDto;

public interface AnswerService {
	List<AnswerDto> list(int question_no);
	boolean create(AnswerDto answerDto);
	boolean modify(AnswerDto answerDto);
	boolean delete(int answer_no);	
}
