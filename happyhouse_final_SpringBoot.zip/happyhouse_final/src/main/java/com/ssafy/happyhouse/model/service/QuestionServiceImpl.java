package com.ssafy.happyhouse.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.happyhouse.model.dto.QuestionDto;
import com.ssafy.happyhouse.model.repo.QuestionRepo;

@Service
public class QuestionServiceImpl implements QuestionService {
	@Autowired
	private QuestionRepo repo;
	
	@Override
	public List<QuestionDto> list() {
		return repo.list();
	}

	@Override
	public QuestionDto search(int question_no) {
		return repo.search(question_no);
	}

	@Override
	public boolean create(QuestionDto questionDto) {
		return repo.create(questionDto)==1;
	}

	@Override
	public boolean modify(QuestionDto questionDto) {
		return repo.modify(questionDto)==1;
	}

	@Override
	public boolean delete(int question_no) {
		return repo.delete(question_no)==1;
	}

}
