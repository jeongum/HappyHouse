package com.ssafy.happyhouse.model.repo;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import com.ssafy.happyhouse.model.dto.MemberDto;


public interface MemberMapper {

	//MemberDto login(Map<String, String> map) throws Exception;
	
	int idCheck(String checkId) throws Exception;
	int registerMember(MemberDto memberDto) throws Exception;
	
	List<MemberDto> listMember() throws Exception;
	MemberDto getMember(String userId) throws Exception;
	int updateMember(MemberDto memberDto) throws Exception;
	int deleteMember(String userId) throws Exception;
	
	public MemberDto login(MemberDto memberDto) throws SQLException;
	public MemberDto userInfo(String userid) throws SQLException;
	int setFavorite(String userid, String sido, String gugun);
}
