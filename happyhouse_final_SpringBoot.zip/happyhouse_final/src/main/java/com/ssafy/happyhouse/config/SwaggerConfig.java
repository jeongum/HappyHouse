package com.ssafy.happyhouse.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import springfox.documentation.builders.*;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

//3.0.0 http://localhost:80/swagger-ui/index.html
@Configuration
@EnableSwagger2
public class SwaggerConfig {
	@Bean
	public Docket api() {
		ApiInfo apiInfo=new ApiInfoBuilder()
			.title("SSAFY API")
			.description("<h2>happyhouse API Reference for Developers</h2>")
			.termsOfServiceUrl("https://edu.ssafy.com")
			.license("SSAFY License")
			.licenseUrl("https://www.ssafy.com/ksp/jsp/swp/etc/swpPrivacy.jsp")
			.version("6.0")
			.build();
		return new Docket(DocumentationType.SWAGGER_2)
			.groupName("ssafyVue")
			.apiInfo(apiInfo)
			.select()
			.apis(RequestHandlerSelectors.basePackage("com.ssafy.happyhouse.controller"))
			.paths(PathSelectors.ant("/**/question/**").or(PathSelectors.ant("/**/answer/**"))) //3.0.0 or 2.9.2
			.build();
	}
}
