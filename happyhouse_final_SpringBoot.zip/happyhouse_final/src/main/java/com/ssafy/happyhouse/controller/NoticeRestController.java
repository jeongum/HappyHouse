package com.ssafy.happyhouse.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.happyhouse.model.dto.NoticeDto;
import com.ssafy.happyhouse.model.dto.QuestionDto;
import com.ssafy.happyhouse.model.service.NoticeService;

import io.swagger.annotations.ApiOperation;



@RestController
@RequestMapping("/notice")
@CrossOrigin("*")
public class NoticeRestController {
	private static final String SUCCESS = "success";
	private static final String FAIL = "fail";
	
	@Autowired
	private NoticeService noticeService;
	
	@GetMapping(value = "/list")
	public ResponseEntity<List<NoticeDto>> userList() throws Exception {
		//System.out.println("memberlist rest 컨트롤러 call..");
		List<NoticeDto> list = noticeService.listNotice();
		
		//for(NoticeDto d : list) System.out.println(d);
		
		if(list != null && !list.isEmpty()) {
			return new ResponseEntity<List<NoticeDto>>(list, HttpStatus.OK);
		} else {
			return new ResponseEntity(HttpStatus.NO_CONTENT);
		}
	}
	
	@DeleteMapping(value = "/list/{noticeno}")
	public ResponseEntity<List<NoticeDto>> userDelete(@PathVariable("noticeno") int noticeno) throws Exception {
		noticeService.deleteNotice(noticeno);
		List<NoticeDto> list = noticeService.listNotice();
		return new ResponseEntity<List<NoticeDto>>(list, HttpStatus.OK);
	}
	
	
	@GetMapping("/list/{noticeno}")
	public ResponseEntity<NoticeDto> searchQuestion(@PathVariable int noticeno) throws Exception {
		//System.out.println("공지사항 viewdetail 컨트롤러");
		NoticeDto noticeDto = noticeService.getNotice(noticeno);
		
		if(noticeDto != null ) {
			return new ResponseEntity<NoticeDto>(noticeDto, HttpStatus.OK);
		} else {
			return new ResponseEntity(HttpStatus.NO_CONTENT);
		}
	}
	
	@PutMapping("/list/{noticeno}")
	public ResponseEntity<String> modifyNotice(@RequestBody NoticeDto noticeDto) {
		System.out.println("공지 수정 컨트롤러 파라메터 : " +noticeDto);
		try {
			noticeService.updateNotice(noticeDto);
			return new ResponseEntity<String>(SUCCESS, HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<String>(FAIL, HttpStatus.NO_CONTENT);
			
		}

	}

	
	@PostMapping
	public ResponseEntity<String> createNotice(@RequestBody NoticeDto noticeDto) {
		System.out.println("공지 등록 컨트롤러 파라메터 : " +noticeDto);
		try {
			noticeService.registerNotice(noticeDto);
			return new ResponseEntity<String>(SUCCESS, HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<String>(FAIL, HttpStatus.NO_CONTENT);
			
		}
	}

	
	

	
	
		
}
