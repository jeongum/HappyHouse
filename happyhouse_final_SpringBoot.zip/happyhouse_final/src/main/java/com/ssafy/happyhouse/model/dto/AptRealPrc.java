package com.ssafy.happyhouse.model.dto;

public class AptRealPrc {
	int id;
	String regionCd;
	String contracttype;
	Double jan, feb, mar, apr, may, jun, jul, aug, sep;
	
	public AptRealPrc(int id, String regionCd, String contracttype, Double jan, Double feb, Double mar, Double apr,
			Double may, Double jun, Double jul, Double aug, Double sep) {
		super();
		this.id = id;
		this.regionCd = regionCd;
		this.contracttype = contracttype;
		this.jan = jan;
		this.feb = feb;
		this.mar = mar;
		this.apr = apr;
		this.may = may;
		this.jun = jun;
		this.jul = jul;
		this.aug = aug;
		this.sep = sep;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getRegionCd() {
		return regionCd;
	}
	public void setRegionCd(String regionCd) {
		this.regionCd = regionCd;
	}
	public String getContracttype() {
		return contracttype;
	}
	public void setContracttype(String contracttype) {
		this.contracttype = contracttype;
	}
	public Double getJan() {
		return jan;
	}
	public void setJan(Double jan) {
		this.jan = jan;
	}
	public Double getFeb() {
		return feb;
	}
	public void setFeb(Double feb) {
		this.feb = feb;
	}
	public Double getMar() {
		return mar;
	}
	public void setMar(Double mar) {
		this.mar = mar;
	}
	public Double getApr() {
		return apr;
	}
	public void setApr(Double apr) {
		this.apr = apr;
	}
	public Double getMay() {
		return may;
	}
	public void setMay(Double may) {
		this.may = may;
	}
	public Double getJun() {
		return jun;
	}
	public void setJun(Double jun) {
		this.jun = jun;
	}
	public Double getJul() {
		return jul;
	}
	public void setJul(Double jul) {
		this.jul = jul;
	}
	public Double getAug() {
		return aug;
	}
	public void setAug(Double aug) {
		this.aug = aug;
	}
	public Double getSep() {
		return sep;
	}
	public void setSep(Double sep) {
		this.sep = sep;
	}
	
	
}
