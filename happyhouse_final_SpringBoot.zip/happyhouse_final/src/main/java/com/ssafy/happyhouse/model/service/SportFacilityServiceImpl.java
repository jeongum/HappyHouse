package com.ssafy.happyhouse.model.service;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.happyhouse.model.dto.SportFacilityDto;
import com.ssafy.happyhouse.model.repo.SportFacilityRepo;
@Service
public class SportFacilityServiceImpl implements SportFacilityService {
	@Autowired
	public SportFacilityRepo srepo;
	
	@Override
	public List<SportFacilityDto> getSportFacility() throws SQLException {
		
		return srepo.getSportFacility();
	}

}
