package com.ssafy.happyhouse.model.dto;

public class SportFacilityDto {
	private String code;
	private String category1;
	private String category2;
	private String service;
	private String place;
	private String url;
	private String lng;
	private String lat;
	private String gu;
	private String tel;
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getCategory1() {
		return category1;
	}
	public void setCategory1(String category1) {
		this.category1 = category1;
	}
	public String getCategory2() {
		return category2;
	}
	public void setCategory2(String category2) {
		this.category2 = category2;
	}
	public String getService() {
		return service;
	}
	public void setService(String service) {
		this.service = service;
	}
	public String getPlace() {
		return place;
	}
	public void setPlace(String place) {
		this.place = place;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getLng() {
		return lng;
	}
	public void setLng(String lng) {
		this.lng = lng;
	}
	public String getLat() {
		return lat;
	}
	public void setLat(String lat) {
		this.lat = lat;
	}
	public String getGu() {
		return gu;
	}
	public void setGu(String gu) {
		this.gu = gu;
	}
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	@Override
	public String toString() {
		return "SportFacilityDto [code=" + code + ", category1=" + category1 + ", category2=" + category2 + ", service="
				+ service + ", place=" + place + ", url=" + url + ", lng=" + lng + ", lat=" + lat + ", gu=" + gu
				+ ", tel=" + tel + "]";
	}
	
	

}
