package com.ssafy.happyhouse.model.service;

import java.util.List;
import java.util.Map;

import com.ssafy.happyhouse.model.dto.HouseInfo;
import com.ssafy.happyhouse.model.dto.SearchCondition;
import com.ssafy.happyhouse.model.dto.SidoGugunCode;

public interface HappyHouseMapService {
	List<SidoGugunCode> getSido() throws Exception;
	List<SidoGugunCode> getGugunInSido(String sido) throws Exception;
	List<HouseInfo> getDongInGugun(String gugun) throws Exception;
	List<HouseInfo> getAptInDong(String dong) throws Exception;
	List<HouseInfo> getAptInName(String aptName) throws Exception;
	Map<String, Object> pagingList(SearchCondition condition);
	List<String> getFavoriteName(String sido, String gugun);
}
