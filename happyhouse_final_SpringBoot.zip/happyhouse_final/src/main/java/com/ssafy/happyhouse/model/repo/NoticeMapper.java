package com.ssafy.happyhouse.model.repo;

import java.util.List;

import com.ssafy.happyhouse.model.dto.NoticeDto;

public interface NoticeMapper {
	void registerNotice(NoticeDto noticeDto) throws Exception;
	
	List<NoticeDto> listNotice() throws Exception;
	
	NoticeDto getNotice(int noticeno) throws Exception;
	
	void updateNotice(NoticeDto noticeDto) throws Exception;
	
	void deleteNotice(int noticeno) throws Exception;
	
}
