package com.ssafy.happyhouse.model.repo;

import java.sql.SQLException;
import java.util.List;

import com.ssafy.happyhouse.model.dto.Bicycle;

public interface BicycleRepo {
	List<Bicycle> getDdareung() throws SQLException;
}
