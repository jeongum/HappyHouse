package com.ssafy.happyhouse.model.service;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.happyhouse.model.dto.Bicycle;
import com.ssafy.happyhouse.model.repo.BicycleRepo;

@Service
public class BicycleServiceImpl implements BicycleService {

	@Autowired
	public BicycleRepo brepo;
	
	@Override
	public List<Bicycle> getDdareung() throws SQLException {
		return brepo.getDdareung();
	}

}
