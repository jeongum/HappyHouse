package com.ssafy.happyhouse.model.service;

import java.security.NoSuchAlgorithmException;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.ssafy.happyhouse.model.dto.MemberDto;

@Service
public class MailService {
    private final char[] pwdTable = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 
                                            'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 
                                            'Y', 'Z', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0' };


    @Autowired
    private JavaMailSender javaMailSender;

    @Autowired
	private MemberService memberService;
    
    public String excuteGenerate() {
        Random random = new Random(System.currentTimeMillis());
        int tablelength = pwdTable.length;
        StringBuffer buf = new StringBuffer();
        
        for(int i = 0; i < 8; i++) {
            buf.append(pwdTable[random.nextInt(tablelength)]);
        }
        
        return buf.toString();
    }

  
    public void sendMail(String userId, String emailAddr) throws Exception {
      
        // SimpleMailMessage (단순 텍스트 구성 메일 메시지 생성할 때 이용)
        SimpleMailMessage simpleMessage = new SimpleMailMessage();
        MemberDto tempDto = memberService.getMember(userId);
		
       
        simpleMessage.setFrom("알잘딱깔센 관리자 <byh64807744@gmail.com>");
        // 수신자 설정
        simpleMessage.setTo(emailAddr);
        
        String tempPwd = excuteGenerate();
       tempDto.setUserPwd(tempPwd);
       memberService.updateMember(tempDto);
		
		
        // 메일 제목
        simpleMessage.setSubject("임시 비밀번호 발급 이메일입니다.");
       
        	
        // 메일 내용
        simpleMessage.setText("임시 비밀번호  : "+tempPwd);
        
        // 메일 발송
        javaMailSender.send(simpleMessage);
        
    }
}