package com.ssafy.happyhouse.model.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.happyhouse.model.dto.HouseInfo;
import com.ssafy.happyhouse.model.dto.SearchCondition;
import com.ssafy.happyhouse.model.dto.SidoGugunCode;
import com.ssafy.happyhouse.model.repo.HappyHouseMapRepo;
import com.ssafy.happyhouse.util.PageNavigation;

@Service
public class HappyHouseMapServiceImpl implements HappyHouseMapService{

	@Autowired
	private HappyHouseMapRepo hrepo;
	
	@Override
	public List<SidoGugunCode> getSido() throws Exception {
		return hrepo.getSido();
	}

	@Override
	public List<SidoGugunCode> getGugunInSido(String sido) throws Exception {
		return hrepo.getGugunInSido(sido);
	}

	@Override
	public List<HouseInfo> getDongInGugun(String gugun) throws Exception {
		return hrepo.getDongInGugun(gugun);
	}

	@Override
	public List<HouseInfo> getAptInDong(String dong) throws Exception {
		return hrepo.getAptInDong(dong);
	}

	@Override
	public List<HouseInfo> getAptInName(String aptName) throws Exception {
		return hrepo.getAptInName(aptName);
	}

	@Override
	public Map<String, Object> pagingList(SearchCondition condition) {
		int totalCount = hrepo.getTotalSearchCount(condition);
		PageNavigation nav = new PageNavigation(condition.getCurrentPage(), totalCount);
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("houses", hrepo.search(condition));
		map.put("navigation", nav);
		return map;
	}

	@Override
	public List<String> getFavoriteName(String sido, String gugun) {
		List<String> favorite = new ArrayList<String>();
		favorite.add(hrepo.getSidoName(sido+"00000000"));
		favorite.add(hrepo.getGugunName(gugun+"00000"));
		return favorite;
	}

}
