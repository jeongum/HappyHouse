package com.ssafy.happyhouse.model.repo;

import java.util.List;

import com.ssafy.happyhouse.model.dto.QuestionDto;

public interface QuestionRepo {
	List<QuestionDto> list();
	QuestionDto search(int question_no);
	int create(QuestionDto questionDto);
	int modify(QuestionDto questionDto);
	int delete(int question_no);
}
