package com.ssafy.happyhouse.model.dto;

public class QuestionDto {
	private int question_no;
	private String type;
	private String title;
	private String content;
	private String question_time;
	private String username;

	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public int getQuestion_no() {
		return question_no;
	}
	public void setQuestion_no(int question_no) {
		this.question_no = question_no;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getQuestion_time() {
		return question_time;
	}
	public void setQuestion_time(String question_time) {
		this.question_time = question_time;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	@Override
	public String toString() {
		return "QuestionDto [question_no=" + question_no + ", title=" + title + ", content=" + content
				+ ", question_time=" + question_time + ", username=" + username + "]";
	}
	
	
	
	
	
}
