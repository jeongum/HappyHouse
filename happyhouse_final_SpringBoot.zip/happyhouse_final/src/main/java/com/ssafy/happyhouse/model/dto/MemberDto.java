package com.ssafy.happyhouse.model.dto;

public class MemberDto {

	private String userName;
	private String userId;
	private String userPwd;
	private String email;
	private String joinDate;
	private String favoriteSido;
	private String favoriteGugun;
	
	public String getFavoriteSido() {
		return favoriteSido;
	}

	public void setFavoriteSido(String favoriteSido) {
		this.favoriteSido = favoriteSido;
	}

	public String getFavoriteGugun() {
		return favoriteGugun;
	}

	public void setFavoriteGugun(String favoriteGugun) {
		this.favoriteGugun = favoriteGugun;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserPwd() {
		return userPwd;
	}

	public void setUserPwd(String userPwd) {
		this.userPwd = userPwd;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getJoinDate() {
		return joinDate;
	}

	public void setJoinDate(String joinDate) {
		this.joinDate = joinDate;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("MemberDto [userName=").append(userName).append(", userId=").append(userId).append(", userPwd=")
				.append(userPwd).append(", email=").append(email).append(", joinDate=").append(joinDate)
				.append(", favoriteSido=").append(favoriteSido).append(", favoriteGugun=").append(favoriteGugun)
				.append("]");
		return builder.toString();
	}


}
