package com.ssafy.happyhouse.controller;

import java.net.URI;
import java.net.URLEncoder;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.ssafy.happyhouse.model.dto.AptRealPrc;
import com.ssafy.happyhouse.model.service.HouseDetailService;

@RestController
@RequestMapping("/housedetail")
public class HouseDetailController {
	
	@Autowired
	HouseDetailService asrv;
	
	private final Logger logger = LoggerFactory.getLogger(HouseDetailController.class);
	
	@GetMapping("/realprc")
	public ResponseEntity<List<AptRealPrc>> apt(@RequestParam("sido") String sido) throws Exception{
		return new ResponseEntity<List<AptRealPrc>>(asrv.getRealPrice(sido+"000"), HttpStatus.OK);
	}

	@GetMapping("/store")
	public ResponseEntity<String> store(@RequestParam("cx") String cx,@RequestParam("cy") String cy) throws Exception{
		  StringBuilder urlBuilder = new StringBuilder("http://apis.data.go.kr/B553077/api/open/sdsc2/storeListInRadius"); /*URL*/
        urlBuilder.append("?" + URLEncoder.encode("serviceKey","UTF-8") + "=Amf9JPnyYWX2qetXZUtx9APCh00EKfsho%2BKIuvAg8xPjHKQsUDWS6eq8EYS6DsLAvnpb%2BvG110d7rNSzFmPr8w%3D%3D"); /*Service Key*/
        urlBuilder.append("&" + URLEncoder.encode("pageNo","UTF-8") + "=" + URLEncoder.encode("1", "UTF-8")); /*페이지번호*/
        urlBuilder.append("&" + URLEncoder.encode("numOfRows","UTF-8") + "=" + URLEncoder.encode("100", "UTF-8")); /*한 페이지 결과 수*/
        urlBuilder.append("&" + URLEncoder.encode("radius","UTF-8") + "=" + URLEncoder.encode("1000", "UTF-8")); /* 반경입력, (미터단위, 최대2000 미터)*/
        urlBuilder.append("&" + URLEncoder.encode("cx","UTF-8") + "=" + URLEncoder.encode(cy, "UTF-8")); /* 원형의 중심점의 경도값으로 WGS84 좌표계 사용*/
        urlBuilder.append("&" + URLEncoder.encode("cy","UTF-8") + "=" + URLEncoder.encode(cx, "UTF-8")); /* 원형의 중심점의 위도값으로 WGS84 좌표계 사용*/
        urlBuilder.append("&" + URLEncoder.encode("type","UTF-8") + "=" + URLEncoder.encode("json", "UTF-8")); /* xml / json*/
        
		RestTemplate rt = new RestTemplate();
		return rt.exchange(
				new URI(urlBuilder.toString()), //{요청할 서버 주소}
                HttpMethod.GET, //{요청할 방식}
                null, // {요청할 때 보낼 데이터}
                String.class 
			);
	}

}
