package com.ssafy.happyhouse.model.repo;

import java.sql.SQLException;
import java.util.List;

import com.ssafy.happyhouse.model.dto.HouseInfo;
import com.ssafy.happyhouse.model.dto.SearchCondition;
import com.ssafy.happyhouse.model.dto.SidoGugunCode;


public interface HappyHouseMapRepo {
	List<SidoGugunCode> getSido() throws SQLException;
	List<SidoGugunCode> getGugunInSido(String sido) throws SQLException;
	List<HouseInfo> getDongInGugun(String gugun) throws SQLException;
	List<HouseInfo> getAptInDong(String dong) throws SQLException;
	List<HouseInfo> getAptInName(String aptName);
	int getTotalSearchCount(SearchCondition condition);
	List<HouseInfo> search(SearchCondition condition);
	String getSidoName(String sido);
	String getGugunName(String gugun);
}
