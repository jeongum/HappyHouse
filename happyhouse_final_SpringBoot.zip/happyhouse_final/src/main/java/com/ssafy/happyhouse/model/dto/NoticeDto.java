package com.ssafy.happyhouse.model.dto;

public class NoticeDto {
	private int noticeno;
	private String subject;
	private String writer;
	private String content;
	private String regTime;
	
	public NoticeDto() {}
	public NoticeDto(int noticeno, String subject, String writer, String content, String regTime) {
		super();
		this.noticeno = noticeno;
		this.subject = subject;
		this.writer = writer;
		this.content = content;
		this.regTime = regTime;
	}
	
	
	public int getNoticeno() {
		return noticeno;
	}
	public void setNoticeno(int noticeno) {
		this.noticeno = noticeno;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getWriter() {
		return writer;
	}
	public void setWriter(String writer) {
		this.writer = writer;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getRegTime() {
		return regTime;
	}
	public void setRegTime(String regTime) {
		this.regTime = regTime;
	}
	@Override
	public String toString() {
		return "NoticeDto [noticeno=" + noticeno + ", subject=" + subject + ", writer=" + writer + ", content="
				+ content + ", regTime=" + regTime + "]";
	}

	
}
