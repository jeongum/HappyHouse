package com.ssafy.happyhouse.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.ssafy.happyhouse.model.dto.NoticeDto;
import com.ssafy.happyhouse.model.dto.SearchCondition;
import com.ssafy.happyhouse.model.service.HappyHouseMapService;
import com.ssafy.happyhouse.model.service.NoticeService;

@Controller
public class HouseInfoController {
	@Autowired
	private HappyHouseMapService hserv;
	
	@GetMapping("/houseinfo/search")
	public String houseinfo() {
		return "houseinfo";
	}

	@GetMapping("/houseinfo/list")
	public String houseinfolist(SearchCondition condition, Model m) {
		Map<String, Object> map = hserv.pagingList(condition);
		m.addAttribute("houses", map.get("houses"));
		m.addAttribute("navigation", map.get("navigation"));
		return "houseinfolist";
	}
	
	@GetMapping("/store")
	public String store() {
		return "store";
	}

	@GetMapping("/bicycle")
	public String bicycle() {
		return "bicycle";
	}
}
