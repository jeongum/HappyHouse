package com.ssafy.happyhouse.model.service;

import java.util.List;

import com.ssafy.happyhouse.model.dto.QuestionDto;

public interface QuestionService {
	List<QuestionDto> list();
	QuestionDto search(int question_no);
	boolean create(QuestionDto questionDto);
	boolean modify(QuestionDto questionDto);
	boolean delete(int question_no);
}
