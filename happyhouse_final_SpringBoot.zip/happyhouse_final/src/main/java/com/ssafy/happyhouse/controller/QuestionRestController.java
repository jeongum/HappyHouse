package com.ssafy.happyhouse.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.ssafy.happyhouse.model.dto.QuestionDto;
import com.ssafy.happyhouse.model.service.QuestionService;

import io.swagger.annotations.ApiOperation;

@CrossOrigin(origins = { "*" }, maxAge = 6000)
@RestController
@RequestMapping("/question")
public class QuestionRestController {
	private static final Logger logger = LoggerFactory.getLogger(QuestionRestController.class);
	private static final String SUCCESS = "success";
	private static final String FAIL = "fail";
	
	@Autowired
	QuestionService questionService;

	@ApiOperation(value = "모든 질문의 정보를 반환한다.", response = List.class)
	@GetMapping
	public ResponseEntity<List<QuestionDto>> listQuestion() {
		logger.debug("listQuestion - 호출");
		return new ResponseEntity<>(questionService.list(), HttpStatus.OK);
	}

	@ApiOperation(value = "question_no에 해당하는 질문의 정보를 반환한다.", response = QuestionDto.class)
	@GetMapping("/{question_no}")
	public ResponseEntity<QuestionDto> searchQuestion(@PathVariable int question_no) {
		logger.debug("searchQuestion - 호출");
		return new ResponseEntity<>(questionService.search(question_no), HttpStatus.OK);
	}

	@ApiOperation(value = "새로운 질문 정보를 입력한다. 그리고 DB입력 성공여부에 따라 'success' 또는 'fail' 문자열을 반환한다.", response = String.class)
	@PostMapping
	public ResponseEntity<String> createQuestion(@RequestBody QuestionDto questionDto) {
		logger.debug("createQuestion - 호출");
		if(questionService.create(questionDto)) {
			return new ResponseEntity<String>(SUCCESS, HttpStatus.OK);
		}
		return new ResponseEntity<String>(FAIL, HttpStatus.NO_CONTENT);
	}

	@ApiOperation(value = "question_no에 해당하는 질문의 정보를 수정한다. 그리고 DB수정 성공여부에 따라 'success' 또는 'fail' 문자열을 반환한다.", response = String.class)
	@PutMapping("{question_no}")
	public ResponseEntity<String> modifyQuestion(@RequestBody QuestionDto questionDto) {
		logger.debug("modifyQuestion - 호출");
		logger.debug("" + questionDto);
		if(questionService.modify(questionDto)) {
			return new ResponseEntity<String>(SUCCESS, HttpStatus.OK);
		}
		return new ResponseEntity<String>(FAIL, HttpStatus.NO_CONTENT);
	}

	@ApiOperation(value = "question_no에 해당하는 질문의 정보를 삭제한다. 그리고 DB삭제 성공여부에 따라 'success' 또는 'fail' 문자열을 반환한다.", response = String.class)
	@DeleteMapping("{question_no}")
	public ResponseEntity<String> deleteQuestion(@PathVariable("question_no") int question_no) {
		logger.debug("deleteQuestion - 호출");
		if(questionService.delete(question_no)) {
			return new ResponseEntity<String>(SUCCESS, HttpStatus.OK);
		}
		return new ResponseEntity<String>(FAIL, HttpStatus.NO_CONTENT);
	}
}
