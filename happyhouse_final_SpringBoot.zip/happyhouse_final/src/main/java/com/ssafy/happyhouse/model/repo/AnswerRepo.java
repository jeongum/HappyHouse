package com.ssafy.happyhouse.model.repo;

import java.util.List;

import com.ssafy.happyhouse.model.dto.AnswerDto;

public interface AnswerRepo {
	List<AnswerDto> list(int question_no);
	int create(AnswerDto answerDto);
	int modify(AnswerDto answerDto);
	int delete(int answer_no);	
}
