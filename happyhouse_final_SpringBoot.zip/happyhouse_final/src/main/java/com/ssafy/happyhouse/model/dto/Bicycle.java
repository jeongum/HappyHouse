package com.ssafy.happyhouse.model.dto;

public class Bicycle {
	private int no;
	private String place;
	private String gu;
	private String address;
	private String lat;
	private String lng;
	private String insDate;
	private String lcdCnt;
	private String qrCnt;
	private String type;
	public int getNo() {
		return no;
	}
	public void setNo(int no) {
		this.no = no;
	}
	public String getPlace() {
		return place;
	}
	public void setPlace(String place) {
		this.place = place;
	}
	public String getGu() {
		return gu;
	}
	public void setGu(String gu) {
		this.gu = gu;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getLat() {
		return lat;
	}
	public void setLat(String lat) {
		this.lat = lat;
	}
	public String getLng() {
		return lng;
	}
	public void setLng(String lng) {
		this.lng = lng;
	}
	public String getInsDate() {
		return insDate;
	}
	public void setInsDate(String insDate) {
		this.insDate = insDate;
	}
	public String getLcdCnt() {
		return lcdCnt;
	}
	public void setLcdCnt(String lcdCnt) {
		this.lcdCnt = lcdCnt;
	}
	public String getQrCnt() {
		return qrCnt;
	}
	public void setQrCnt(String qrCnt) {
		this.qrCnt = qrCnt;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Bicycle [no=").append(no).append(", place=").append(place).append(", gu=").append(gu)
				.append(", address=").append(address).append(", lat=").append(lat).append(", lon=").append(lng)
				.append(", insDate=").append(insDate).append(", lcdCnt=").append(lcdCnt).append(", qrCnt=")
				.append(qrCnt).append(", type=").append(type).append("]");
		return builder.toString();
	}
	
}
