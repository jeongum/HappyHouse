package com.ssafy.happyhouse.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.ssafy.happyhouse.model.dto.AnswerDto;
import com.ssafy.happyhouse.model.service.AnswerService;

import io.swagger.annotations.ApiOperation;

@CrossOrigin(origins = { "*" }, maxAge = 6000)
@RestController
@RequestMapping("/answer")
public class AnswerRestController {
	private static final Logger logger = LoggerFactory.getLogger(AnswerRestController.class);
	private static final String SUCCESS = "success";
	private static final String FAIL = "fail";
	
	@Autowired
	AnswerService answerService;

	@ApiOperation(value = "question_no에 해당하는 답변의 정보를 반환한다.", response = List.class)
	@GetMapping("{question_no}")
	public ResponseEntity<List<AnswerDto>> listBook(@PathVariable("question_no") int question_no) {
		logger.debug("listanswer - 호출");
		return new ResponseEntity<>(answerService.list(question_no), HttpStatus.OK);
	}

	@ApiOperation(value = "새로운 답변 정보를 입력한다. 그리고 DB입력 성공여부에 따라 'success' 또는 'fail' 문자열을 반환한다.", response = String.class)
	@PostMapping
	public ResponseEntity<String> createAnswer(@RequestBody AnswerDto answerDto) {
		logger.debug("createAnswer - 호출");
		if(answerService.create(answerDto)) {
			return new ResponseEntity<String>(SUCCESS, HttpStatus.OK);
		}
		return new ResponseEntity<String>(FAIL, HttpStatus.NO_CONTENT);
	}

	@ApiOperation(value = "answer_no에 해당하는 질문의 정보를 수정한다. 그리고 DB수정 성공여부에 따라 'success' 또는 'fail' 문자열을 반환한다.", response = String.class)
	@PutMapping
	public ResponseEntity<String> modifyAnswer(@RequestBody AnswerDto answerDto) {
		logger.debug("modifyAnswer - 호출");
		logger.debug("" + answerDto);
		if(answerService.modify(answerDto)) {
			return new ResponseEntity<String>(SUCCESS, HttpStatus.OK);
		}
		return new ResponseEntity<String>(FAIL, HttpStatus.NO_CONTENT);
	}

	@ApiOperation(value = "answer_no 에 해당하는 질문의 정보를 삭제한다. 그리고 DB삭제 성공여부에 따라 'success' 또는 'fail' 문자열을 반환한다.", response = String.class)
	@DeleteMapping("{answer_no}")
	public ResponseEntity<String> deleteBook(@PathVariable("answer_no") int answer_no) {
		logger.debug("deleteBook - 호출");
		if(answerService.delete(answer_no)) {
			return new ResponseEntity<String>(SUCCESS, HttpStatus.OK);
		}
		return new ResponseEntity<String>(FAIL, HttpStatus.NO_CONTENT);
	}
}
