package com.ssafy.happyhouse.model.service;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.happyhouse.model.dto.MemberDto;
import com.ssafy.happyhouse.model.repo.MemberMapper;

@Service
public class MemberServiceImpl implements MemberService {

	@Autowired
	private SqlSession sqlSession;
	
	public String encrypt(String text) throws NoSuchAlgorithmException {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        md.update(text.getBytes());

        return bytesToHex(md.digest());
    }
	
	private String bytesToHex(byte[] digest) {
		StringBuilder builder = new StringBuilder();
        for (byte b : digest) {
            builder.append(String.format("%02x", b));
        }
        return builder.toString();
	}

	@Override
	public int idCheck(String checkId) throws Exception {
		return sqlSession.getMapper(MemberMapper.class).idCheck(checkId); // 0 or 1
	}

	@Override
	public boolean registerMember(MemberDto memberDto) throws Exception {
//		validation check
		//System.out.println("서비스에서 oringin pwd :" +memberDto.getUserPwd());
		memberDto.setUserPwd(encrypt(memberDto.getUserPwd()) );
		//System.out.println("암호화 pwd "+ memberDto.getUserPwd());
		return sqlSession.getMapper(MemberMapper.class).registerMember(memberDto)==1;
	}

	
	@Override
	public List<MemberDto> listMember() throws Exception {
		return sqlSession.getMapper(MemberMapper.class).listMember();
	}

	@Override
	public MemberDto getMember(String userId) throws Exception {
		return sqlSession.getMapper(MemberMapper.class).getMember(userId);
	}

	@Override
	public boolean updateMember(MemberDto memberDto) throws Exception {
		memberDto.setUserPwd(encrypt(memberDto.getUserPwd()) );
		return sqlSession.getMapper(MemberMapper.class).updateMember(memberDto)==1;
	}

	@Override
	public boolean deleteMember(String userId) throws Exception {
		return sqlSession.getMapper(MemberMapper.class).deleteMember(userId)==1;
	}

	@Override
	public MemberDto login(MemberDto memberDto) throws Exception {
		if(memberDto.getUserId() == null || memberDto.getUserPwd() == null)
			return null;
		
		memberDto.setUserPwd(encrypt(memberDto.getUserPwd()));
		return sqlSession.getMapper(MemberMapper.class).login(memberDto);
	}

	@Override
	public MemberDto userInfo(String userid) throws Exception {
		return sqlSession.getMapper(MemberMapper.class).userInfo(userid);
	}

	@Override
	public boolean setFavorite(String userid, String sido, String gugun) {
		return sqlSession.getMapper(MemberMapper.class).setFavorite(userid, sido, gugun)==1;

	}
}
