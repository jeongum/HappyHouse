<template>
  <div>
    <div class="hero-wrap hero-bread" :style="{
      backgroundImage: 'url(' + require('@/assets/img/house3.jpg') + ')',
    }">
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center">
          <div class="col-md-9 ftco-animate text-center fadeInUp ftco-animated">
            <p class="breadcrumbs"><span class="mr-2"><a href="#">Home</a></span> <span>게시판</span></p>
            <h1 class="mb-0 bread">공지사항</h1>
            <b-button class="btn btn-primary mt-3" pill @click="
                $router.push({
                  name: 'NoticeList',
                })
              ">목록으로</b-button>
          </div>
        </div>
      </div>
  </div>
    <div class="ftco-section ftco-degree-bg">
      <b-container class="bv-example-row mt-3">
        <b-row class="mb-1">
          <b-col>
            <b-card> 
              <b-card-header>
                <div class=''>
                  <h3 class='title text-center'>{{ notice.subject }}</h3>
                </div>
                <div class='row m-0'>
                  <h6> {{ notice.writer }}</h6>
                  <h6 class='ml-auto'>{{notice.regTime}}</h6>
                </div>
              </b-card-header>
              <b-card-body class="text-left">
                <div>
                  {{  notice.content }}
                </div>
              </b-card-body>
            </b-card>
          </b-col>
        </b-row>
        <hr>
        <b-row class="m-0">
          <b-col class="text-right">
            <b-button
              v-if="isAdmin"
              variant="outline-info"
              size="sm"
              class="w-30 mr-2"
              @click="movemodifyNotice"
              >공지사항 수정</b-button
            >
            <b-button
              v-if="isAdmin"
              variant="outline-danger"
              size="sm"
              class="w-30"
              @click="deleteNotice"
              >공지사항 삭제</b-button
            >
          </b-col>
        </b-row>
      </b-container>
    </div>
  </div>
</template>

<script>
import http from "@/util/http-common";
import { mapMutations, mapState } from "vuex";
const memberStore = "memberStore";
const admin = "admin";
const 관리자 = "관리자";
export default {
  components: {},
  data() {
    return {
      notice: {},
      isAdmin: false,
    };
  },
  computed: {
    ...mapState(memberStore, ["userInfo"]),
  },
  created() {
    if (this.userInfo != null) {
      if (
        admin.includes(this.userInfo.userName) ||
        관리자.includes(this.userInfo.userName)
      ) {
        this.isAdmin = true;
      }
    }
    http.get(`/notice/list/${this.$route.params.noticeno}`).then(({ data }) => {
      this.notice = data;
      //console.log(this.notice);
    });
  },
  methods: {
    ...mapMutations(memberStore, ["SET_IS_LOGIN", "SET_USER_INFO"]),
    movemodifyNotice() {
      if (this.userInfo == null) {
        alert("공지사항 수정은 관리자만 가능합니다 !");
      } else if (
        admin.includes(this.userInfo.userName) ||
        관리자.includes(this.userInfo.userName)
      ) {
        this.$router.push({ name: "NoticeModify" });
      } else {
        alert("공지사항 수정은 관리자만 가능합니다 !");
      }
    },
    deleteNotice() {
      if (this.userInfo == null) {
        alert("공지사항 삭제은 관리자만 가능합니다 !");
      } else if (
        admin.includes(this.userInfo.userName) ||
        관리자.includes(this.userInfo.userName)
      ) {
        if (confirm("정말로 삭제하시겠습니까?")) {
          http
            .delete(`/notice/list/${this.$route.params.noticeno}`)
            .then(() => {
              alert("공지사항이 삭제되었습니다.");
              this.$router.push({ name: "NoticeList" });
              //console.log(this.notice);
            });
        }
      } else {
        alert("공지사항 삭제은 관리자만 가능합니다 !");
      }
    },
  },
};
</script>

<style scoped>
.hero-wrap.hero-bread {
    padding: 10em 0;
}
.hero-wrap .slider-text .breadcrumbs {
    text-transform: uppercase;
    font-size: 12px;
    letter-spacing: 3px;
    margin-bottom: 0;
    z-index: 99;
    font-weight: 300;
}
.hero-wrap .slider-text .bread {
    font-weight: 800;
    color: #fff;
    font-size: 30px;
    font-family: "Poppins", Arial, sans-serif;
    letter-spacing: 3px;
    text-transform: uppercase;
}
.hero-wrap .slider-text .breadcrumbs span {
    color: #fff;
}
.type-btn{
  padding: 10px 20px;
  border: none;
}
.type-btn.select{
  background: #82ae46;
}
.btn.btn-primary:hover, .btn.btn-primary:focus{
  background: #5b7931;
  border: 3px solid #5b7931
}  
.card{
  border:none;
}
.card-header{
  border-top: 1px solid rgba(0, 0, 0, 0.125);
  background: white;
}
.card-header h6{
    font-weight: 600;
    color: rgba(0,0,0,0.5);
}
.card-header .title{
  font-weight: 800;
  font-size: 30px;
  font-family: "Poppins", Arial, sans-serif;
  letter-spacing: 3px;
}
</style>