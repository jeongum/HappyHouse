<template>
  <div>
    <b-table-simple hover responsive class="mt-5 text-center">
      <b-thead>
        <tr>
          <b-th style="width:10%">번호</b-th>
          <b-th>제목</b-th>
          <b-th style="width:20%">작성일</b-th>
        </tr>
      </b-thead>
      <tr v-for="(notice, index) in paginatedData" :key="index">
        <b-td>{{ index + 1 }}</b-td>
        <b-td><a href="#" @click="
              $router.push({
                name: 'NoticeView',
                params: { noticeno: notice.noticeno },
              })
            "> {{ notice.subject }} &nbsp; <b-badge class="new" v-if="isNew(notice.regTime)">new!</b-badge></a></b-td>
        <b-td>{{ notice.regTime }}</b-td>
      </tr>
    </b-table-simple>
    <div class="btn-cover text-center">
      <b-button :disabled="pageNum === 0" @click="prevPage" class="page-btn">
        이전
      </b-button>
      <span class="page-count">{{ pageNum + 1 }} / {{ pageCount }} 페이지</span>
      <b-button
        :disabled="pageNum >= pageCount - 1"
        @click="nextPage"
        class="page-btn"
      >
        다음
      </b-button>
    </div>
  </div>
</template>

<script>
export default {
  name: "paginated-list",
  data() {
    return {
      pageNum: 0,
    };
  },
  props: {
    listArray: {
      type: Array,
      required: true,
    },
    pageSize: {
      type: Number,
      required: false,
      default: 5,
    },
  },
  methods: {
    nextPage() {
      this.pageNum += 1;
    },
    prevPage() {
      this.pageNum -= 1;
    },
    isNew(someDate){
      const data = new Date(someDate);
      const today = new Date()
      return data.getDate() == today.getDate() &&
        data.getMonth() == today.getMonth() &&
        data.getFullYear() == today.getFullYear()
    }
  },
  computed: {
    pageCount() {
      let listLeng = this.listArray.length,
        listSize = this.pageSize,
        page = Math.floor(listLeng / listSize);
      if (listLeng % listSize > 0) page += 1;

      return page;
    },
    paginatedData() {
      const start = this.pageNum * this.pageSize,
        end = start + this.pageSize;
      return this.listArray.slice(start, end);
    },
  },
};
</script>

<style scoped>
.btn-cover {
  margin-top: 1.5rem;
  text-align: center;
}
.btn-cover .page-btn {
  width: 5rem;
  height: 2rem;
  letter-spacing: 0.5px;
}
.btn-cover .page-count {
  padding: 0 1rem;
}
thead{
  background: #82ae46;
  color: #fff;
}
.new{
  background: #FFE400
}
</style>
