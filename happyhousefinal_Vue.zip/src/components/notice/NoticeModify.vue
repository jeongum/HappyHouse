<template>
  <div>
    <div class="hero-wrap hero-bread" :style="{
      backgroundImage: 'url(' + require('@/assets/img/house3.jpg') + ')',
    }">
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center">
          <div class="col-md-9 ftco-animate text-center fadeInUp ftco-animated">
            <p class="breadcrumbs"><span class="mr-2"><a href="#">Home</a></span> <span>게시판</span></p>
            <h1 class="mb-0 bread">공지사항 수정</h1>
          </div>
        </div>
      </div>
    </div>
    <b-container class="bv-example-row mt-5">
      <b-row class="mb-1">
        <b-col class="text-left">
          <b-form>
            <b-form-group
              id="subject-group"
              label="제목:"
              label-for="subject"
            >
              <b-form-input
                id="subject"
                ref="subject"
                v-model="notice.subject"
                type="text"
                required
                placeholder="제목 입력..."
              />
            </b-form-group>

            <b-form-group
              id="content-group"
              label="내용:"
              label-for="content"
              ref="content"
            >
              <b-form-textarea
                id="content"
                v-model="notice.content"
                placeholder="내용 입력..."
                rows="10"
                max-rows="15"
              ></b-form-textarea>
            </b-form-group>

            <b-button variant="primary" class="m-1" @click="modifyNotice"
              >수정</b-button
            >

            <b-button variant="primary" class="m-1" @click="
                $router.push({
                  name: 'NoticeList',
                })
              "
              >목록</b-button
            >
          </b-form>
        </b-col>
      </b-row>
    </b-container>
  </div>
</template>

<script>
import http from "@/util/http-common";
import { mapMutations, mapState } from "vuex";
const memberStore = "memberStore";
export default {
  components: {},
  data() {
    return {
      notice: {},
    };
  },
  computed: {
    ...mapState(memberStore, ["userInfo"]),
  },
  created() {
    http.get(`/notice/list/${this.$route.params.noticeno}`).then(({ data }) => {
      this.notice = data;
    });
  },
  methods: {
    ...mapMutations(memberStore, ["SET_IS_LOGIN", "SET_USER_INFO"]),
    modifyNotice() {
      http
        .put(`/notice/list/${this.noticeno}`, {
          // notice: this.notice,
          noticeno: this.notice.noticeno,
          subject: this.notice.subject,
          content: this.notice.content,
          writer: this.userInfo.userName,
        })
        .then(({ data }) => {
          let msg = "수정 처리시 문제가 발생했습니다.";
          if (data === "success") {
            msg = "수정이 완료되었습니다.";
          }
          alert(msg);
          this.$router.push({
            name: "NoticeView",
            params: { noticeno: this.notice.noticeno },
          });
        });
    },
  },
};
</script>
<style scoped>
.hero-wrap.hero-bread {
    padding: 10em 0;
}
.hero-wrap .slider-text .breadcrumbs {
    text-transform: uppercase;
    font-size: 12px;
    letter-spacing: 3px;
    margin-bottom: 0;
    z-index: 99;
    font-weight: 300;
}
.hero-wrap .slider-text .bread {
    font-weight: 800;
    color: #fff;
    font-size: 30px;
    font-family: "Poppins", Arial, sans-serif;
    letter-spacing: 3px;
    text-transform: uppercase;
}
.hero-wrap .slider-text .breadcrumbs span {
    color: #fff;
}
.type-btn{
  padding: 10px 20px;
  border: none;
}
.type-btn.select{
  background: #82ae46;
}
.btn.btn-primary:hover, .btn.btn-primary:focus{
  background: #5b7931;
  border: 3px solid #5b7931
}  
</style>
