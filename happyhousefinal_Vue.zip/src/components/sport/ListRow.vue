<template>
  <tr @click="moveDetail">
    <td>{{ no }}</td>
    <td>{{ sportinfo.MAXCLASSNM }}</td>
    <td>{{ sportinfo.MAXCLASSNM }}</td>
    <td>{{ sportinfo.MINCLASSNM }}</td>
    <td>{{ sportinfo.SVCNM }}</td>
  </tr>
</template>

<script>
export default {
  props: {
    no: Number,
    sportinfo: Object,
  },
  created() {
    //console.log(this.sportinfo);
  },
  methods: {
    moveDetail() {
      this.$router.push({
        name: "SportInfoDetail",
        params: { info: this.sportinfo, no: this.no },
      });
    },
  },
};
</script>

<style></style>
