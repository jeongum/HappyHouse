<template>
<div>
  <div class="hero-wrap hero-bread" :style="{
      backgroundImage: 'url(' + require('@/assets/img/house3.jpg') + ')',
    }">
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center">
          <div class="col-md-9 ftco-animate text-center fadeInUp ftco-animated">
            <p class="breadcrumbs"><span class="mr-2"><a href="#">Home</a></span> <span>Health</span></p>
            <h1 class="mb-0 bread">체육시설</h1>
          </div>
        </div>
      </div>
  </div>
  <b-container class="bv-example-row mt-3 text-center">
    <b-row>
      <b-col v-if="showinfos.length">
        <b-table-simple hover responsive>
          <b-thead>
            <b-tr>
              <b-th>번호</b-th>
              <b-th>장소</b-th>
              <b-th>대분류</b-th>
              <b-th>소분류</b-th>
              <b-th>서비스</b-th>
            </b-tr>
          </b-thead>
          <b-tbody>
            <list-row
              v-for="(info, index) in showinfos"
              :key="index"
              :sportinfo="info"
              :no="index + 1"
            />
          </b-tbody>
        </b-table-simple>
      </b-col>
      <b-col v-else class="text-center"
        >등록한 관심지역 주변 체육시설 정보가 없습니다.</b-col
      >
    </b-row>
  </b-container>
</div>
</template>

<script>
//import http from "@/util/http-common";
import ListRow from "@/components/sport/ListRow.vue";
import { mapMutations, mapState } from "vuex";
const memberStore = "memberStore";

export default {
  components: {
    ListRow,
  },
  data() {
    return {
      showinfos: [],
      sportinfo: {},
    };
  },
  computed: {
    ...mapState(memberStore, ["userInfo"]),
    ...mapState(["gugun","sportinfos"]),
  },
  mounted() {
    for (var item of this.sportinfos) {
      if (item.AREANM == this.gugun.name) {
        this.showinfos.push(item);
      }
    }
  },
  methods: {
    ...mapMutations(memberStore, ["SET_IS_LOGIN", "SET_USER_INFO"]),
  },
};
</script>

<style scoped>
.hero-wrap.hero-bread {
    padding: 10em 0;
}
.hero-wrap .slider-text .breadcrumbs {
    text-transform: uppercase;
    font-size: 12px;
    letter-spacing: 3px;
    margin-bottom: 0;
    z-index: 99;
    font-weight: 300;
}
.hero-wrap .slider-text .bread {
    font-weight: 800;
    color: #fff;
    font-size: 30px;
    font-family: "Poppins", Arial, sans-serif;
    letter-spacing: 3px;
    text-transform: uppercase;
}
.hero-wrap .slider-text .breadcrumbs span {
    color: #fff;
}
thead{
  background: #82ae46;
  color: #fff;
}
</style>
