<template>
  <div>
    <div
      class="hero-wrap hero-bread"
      :style="{
        backgroundImage: 'url(' + require('@/assets/img/house3.jpg') + ')',
      }"
    >
      <div class="container">
        <div
          class="
            row
            no-gutters
            slider-text
            align-items-center
            justify-content-center
          "
        >
          <div class="col-md-9 ftco-animate text-center fadeInUp ftco-animated">
            <p class="breadcrumbs">
              <span class="mr-2"><a href="#">Home</a></span>
              <span>체육시설</span>
            </p>
            <h1 class="mb-0 bread">{{ info.PLACENM }}</h1>
          </div>
        </div>
      </div>
    </div>
    <b-container style="padding: 5rem 0">
      <b-row>
        <b-col cols="6">
          <img :src="info.IMGURL" style="width: 100%" />
        </b-col>
        <b-col>
          <b-table-simple responsive>
            <b-tbody>
              <b-tr>
                <b-th>시설명</b-th>
                <b-td>{{ info.PLACENM }}</b-td>
              </b-tr>
              <b-tr>
                <b-th>분류</b-th>
                <b-td>{{ info.MINCLASSNM }}</b-td>
              </b-tr>
              <b-tr>
                <b-th>접수기간</b-th>
                <b-td>{{ info.RCPTBGNDT }} - {{ info.RCPTENDDT }}</b-td>
              </b-tr>
              <b-tr>
                <b-th>서비스기간</b-th>
                <b-td>{{ info.SVCOPNBGNDT }} - {{ info.SVCOPNENDDT }}</b-td>
              </b-tr>
              <b-tr>
                <b-th>대상</b-th>
                <b-td>{{ info.USETGTINFO }}</b-td>
              </b-tr>
              <b-tr>
                <b-th>결제방법</b-th>
                <b-td>{{ info.PAYATNM }}</b-td>
              </b-tr>
              <b-tr>
                <b-th>상태</b-th>
                <b-td>{{ info.SVCSTATNM }}</b-td>
              </b-tr>
              <b-tr>
                <b-th>예약</b-th>
                <b-td
                  ><b-button class="btn btn-primary" @click="reservation"
                    >예약 하기 링크</b-button
                  ></b-td
                >
              </b-tr>
            </b-tbody>
          </b-table-simple>
        </b-col>
      </b-row>
      <hr />
      <div class="justify-content-center text-center">
        <span class="subheading">DETAIL</span>
        <h1 class="mb-0 bread" style="color: #000">상세정보</h1>
      </div>
      <b-card class="mt-3" style="background-color: #f7f6f2">
        <b-card-text>
          <div v-html="info.DTLCONT"></div>
        </b-card-text>
      </b-card>
      <div id="map" style="width: 100%; height: 500px"></div>
      <br /><br />
    </b-container>
  </div>
</template>

<script>
export default {
  data() {
    return {
      info: {},
    };
  },
  mounted() {
    if (window.kakao && window.kakao.maps) {
      this.initMap();
    } else {
      const script = document.createElement("script");
      /* global kakao */
      script.onload = () => kakao.maps.load(this.initMap);
      script.src =
        "//dapi.kakao.com/v2/maps/sdk.js?autoload=false&appkey=915cffed372954b7b44804ed422b9cf0&libraries=services";
      document.head.appendChild(script);
    }
  },
  created() {
    this.info = this.$route.params.info;
  },
  methods: {
    reservation() {
      //console.log(this.info);
      window.open(this.info.SVCURL);
    },
    initMap() {
      var imageSrc =
        "https://t1.daumcdn.net/localimg/localimages/07/mapapidoc/markerStar.png";

      var mapContainer = document.getElementById("map"), // 지도를 표시할 div
        mapOption = {
          center: new kakao.maps.LatLng(this.info.Y, this.info.X),
          level: 3, // 지도의 확대 레벨
        };

      var map = new kakao.maps.Map(mapContainer, mapOption); // 지도를 생성합니다

      // 마커 이미지의 이미지 크기 입니다
      var imageSize = new kakao.maps.Size(24, 35);

      // 마커 이미지를 생성합니다
      var markerImage = new kakao.maps.MarkerImage(imageSrc, imageSize);

      // 마커를 생성합니다
      new kakao.maps.Marker({
        map: map, // 마커를 표시할 지도
        position: new kakao.maps.LatLng(this.info.Y, this.info.X), // 마커를 표시할 위치
        title: this.title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
        image: markerImage, // 마커 이미지
      });
    },
  },
};
</script>

<style scoped>
.hero-wrap.hero-bread {
  padding: 10em 0;
}
.hero-wrap .slider-text .breadcrumbs {
  text-transform: uppercase;
  font-size: 12px;
  letter-spacing: 3px;
  margin-bottom: 0;
  z-index: 99;
  font-weight: 300;
}
.bread {
  font-weight: 800;
  color: #fff;
  font-size: 30px;
  font-family: "Poppins", Arial, sans-serif;
  letter-spacing: 3px;
  text-transform: uppercase;
}
.hero-wrap .slider-text .breadcrumbs span {
  color: #fff;
}
table {
  text-align: center;
}
.subheading {
  font-size: 18px;
  display: block;
  margin-bottom: 10px;
  font-family: "Lora", Georgia, serif;
  font-style: italic;
  color: #82ae46;
}
thead {
  background: #82ae46;
  color: #fff;
}
.btn.btn-primary {
  background: #82ae46;
  border: 3px solid #82ae46;
  color: #fff !important;
}
</style>
