<template>
  <div>
    <b-navbar toggleable="lg">
      <div class="container">
        <b-navbar-brand class="nav-brand" href="#">
          <router-link to="/">
            HAPPYHOUSE
          </router-link>
        </b-navbar-brand>
        <b-navbar-toggle target="nav-collapse"></b-navbar-toggle>
        <b-collapse id="nav-collapse" is-nav>
          <b-navbar-nav class="ml-auto">
            <b-nav-item  href="#">
              <router-link to="/house">거래정보</router-link>
            </b-nav-item>
            <b-nav-item-dropdown text="Health" right>
              <b-dropdown-item href="#">
                <router-link to="/sport">체육시설</router-link>
              </b-dropdown-item>
              <b-dropdown-item href="#">
                <router-link to="/bicycle" >따릉이 찾기</router-link>
              </b-dropdown-item>
            </b-nav-item-dropdown>
            <b-nav-item-dropdown text="게시판" right>
              <b-dropdown-item href="#">
                <router-link to="/qna" >자유게시판</router-link>
              </b-dropdown-item>
              <b-dropdown-item href="#">
                <router-link to="/notice" >공지사항</router-link>
              </b-dropdown-item>
            </b-nav-item-dropdown>

            <b-nav-item-dropdown class="padding-none" v-if="userInfo" no-caret>
              <template slot="button-content">
                  <span>{{ userInfo.userName }}님</span>
                  <b-avatar variant="secondary"  size="sm"></b-avatar>
              </template>
              <b-dropdown-item              
                ><router-link
                  :to="{ name: 'MyPage' }"
                  >내정보보기</router-link
                ></b-dropdown-item
              >
              <b-dropdown-item
                class=""
                @click.prevent="onClickLogout"
                >로그아웃</b-dropdown-item
              >
            </b-nav-item-dropdown>

            <b-nav-item-dropdown v-else no-caret >
              <template slot="button-content" >
                  <b-avatar variant="secondary" size="sm"></b-avatar>
              </template>
              <b-dropdown-item href="#"
                ><router-link :to="{ name: 'SignIn' }" class="link"
                  >로그인</router-link
                ></b-dropdown-item
              >
              <b-dropdown-item href="#"
                ><router-link :to="{ name: 'SignUp' }" class="link"
                  >회원가입</router-link
                ></b-dropdown-item
              >
            </b-nav-item-dropdown>
          </b-navbar-nav>
        </b-collapse>
      </div>
    </b-navbar>
  </div>
</template>

<script>
import { mapState, mapMutations } from "vuex";

const memberStore = "memberStore";

export default {
  name: "NaviBar",
  computed: {
    ...mapState(memberStore, ["isLogin", "userInfo"]),
  },
  methods: {
    ...mapMutations(memberStore, ["SET_IS_LOGIN", "SET_USER_INFO"]),
    onClickLogout() {
      this.SET_IS_LOGIN(false);
      this.SET_USER_INFO(null);
      sessionStorage.removeItem("access-token");
      if (this.$route.path != "/") this.$router.push({ name: "Home" });
    },
  },
};
</script>

<style>

.navbar-light .navbar-brand {
  color: #82ae46 !important;
  font-weight: 800;
  font-size: 20px;
  text-transform: uppercase;
}
.navbar-light .navbar-brand:hover, .navbar-light .navbar-brand:focus {
  color: #000000 !important; 
}
.navbar-light .navbar-nav > .nav-item > .nav-link {
  font-size: 11px;
  padding-top: 1.5rem;
  padding-bottom: 1.5rem;
  padding-left: 20px;
  padding-right: 20px;
  font-weight: 400;
  color: #000000;
  text-transform: uppercase;
  letter-spacing: 2px;
  opacity: 1 !important; 
}
.navbar-light .navbar-nav > .nav-item:last-child > .nav-link{
  padding: 1.2rem !important;
  color: rgba(0,0,0,0.5);
}
.dropdown-item{
  font-size: 14px;
  font-weight: 400;
  color: #000000;
  text-transform: uppercase;
  letter-spacing: 2px;
}
.navbar-light .navbar-nav > .nav-item:last-child > .nav-link .b-avatar{
  margin-left: 0.2rem
}
</style>