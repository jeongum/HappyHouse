<template>
  <div>
    <div class="hero-wrap hero-bread" :style="{
      backgroundImage: 'url(' + require('@/assets/img/house3.jpg') + ')',
    }">
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center">
          <div class="col-md-9 ftco-animate text-center fadeInUp ftco-animated">
            <p class="breadcrumbs"><span class="mr-2"><a href="#">Home</a></span> <span>게시판</span></p>
            <h1 class="mb-0 bread">{{qna.type}}</h1>
          </div>
        </div>
      </div>
  </div>
    <div class="ftco-section ftco-degree-bg">
      <b-container class="bv-example-row my-3">
        <b-row class="mb-1 mt-5">
          <b-col class="text-left">
            <b-button variant="outline-primary" class="w-30" @click="listQnA"
              >목록</b-button
            >
          </b-col>
          <b-col class="text-right">
            <b-button
              variant="outline-info"
              size="sm"
              class="w-30 mr-2"
              @click="moveModifyQnA"
              >글수정</b-button
            >
            <b-button
              variant="outline-danger"
              size="sm"
              class="w-30"
              @click="deleteQnA"
              >글삭제</b-button
            >
          </b-col>
        </b-row>
        <view-detail></view-detail>
        <hr>
        <answer-write :question_no="this.question_no" />
        <answer-write
          v-if="isModifyShow && this.modifyAnswer != null"
          :modifyAnswer="this.modifyAnswer"
          @modify-answer-cancel="onModifyAnswerCancel"
        />
        <answer
          v-for="(answer, index) in answers"
          :key="index"
          :answer="answer"
          @modify-answer="onModifyAnswer"
        />
      </b-container>
    </div>
  </div>
</template>

<script>
import ViewDetail from "@/components/qna/include/ViewDetail.vue";
import http from "@/util/http-common";

import { mapGetters, mapMutations, mapState } from "vuex";
const memberStore = "memberStore";
import AnswerWrite from "@/components/qna/include/answer/AnswerWrite.vue";
import Answer from "@/components/qna/include/answer/Answer.vue";

export default {
  components: {
    ViewDetail,
    AnswerWrite,
    Answer,
  },
  data() {
    return {
      // isUser: false,
      question_no: null,
      userName: "",
      isModifyShow: false,
      modifyAnswer: Object,
    };
  },
  computed: {
    ...mapGetters(["qna"]),
    ...mapGetters(["answers"]),
    ...mapState(memberStore, ["userInfo"]),
  },
  created() {
    this.question_no = this.$route.params.question_no;
    this.$store.dispatch("getQnA", this.question_no);
    this.$store.dispatch("getAnswers", this.question_no);

    // if (this.userInfo != null) {
    //   if (this.userInfo.userName == this.qna.username) {
    //     this.isUser = true;
    //   }
    // }
    console.log(this.userInfo);
  },
  methods: {
    ...mapMutations(memberStore, ["SET_IS_LOGIN", "SET_USER_INFO"]),

    listQnA() {
      // this.$router.push("/qna/list");
      this.$router.push({ name: "QnAList" });
    },
    moveModifyQnA() {
      // this.$router.push(`/qna/modify/${this.question_no}`);
      if (this.userInfo != null) {
        if (this.userInfo.userName == this.qna.username) {
          this.$router.push({ name: "QnAModify" });
        } else {
          alert("작성자만 수정가능합니다 !");
        }
      }
    },
    deleteQnA() {
      if (this.userInfo != null) {
        if (this.userInfo.userName == this.qna.username) {
          if (confirm("삭제할까요?")) {
            http.delete(`/question/${this.question_no}`).then(({ data }) => {
              let msg = "삭제 처리시 문제가 발생했습니다.";
              if (data === "success") {
                msg = "삭제가 완료되었습니다.";
              }
              alert(msg);
              // this.$router.push("/qna/list");
              this.$router.push({ name: "QnAList" });
            });
          }
        } else {
          alert("작성자만 삭제가능합니다 !");
        }
      }
    },
    onModifyAnswer(answer) {
      this.modifyAnswer = answer;
      this.isModifyShow = true;
    },
    onModifyAnswerCancel(isShow) {
      this.isModifyShow = isShow;
    },
  },
};
</script>

<style scoped>
.hero-wrap.hero-bread {
    padding: 10em 0;
}
.hero-wrap .slider-text .breadcrumbs {
    text-transform: uppercase;
    font-size: 12px;
    letter-spacing: 3px;
    margin-bottom: 0;
    z-index: 99;
    font-weight: 300;
}
.hero-wrap .slider-text .bread {
    font-weight: 800;
    color: #fff;
    font-size: 30px;
    font-family: "Poppins", Arial, sans-serif;
    letter-spacing: 3px;
    text-transform: uppercase;
}
.hero-wrap .slider-text .breadcrumbs span {
    color: #fff;
}
.type-btn{
  padding: 10px 20px;
  border: none;
}
.type-btn.select{
  background: #82ae46;
}
.btn.btn-primary:hover, .btn.btn-primary:focus{
  background: #5b7931;
  border: 3px solid #5b7931
}  
</style>