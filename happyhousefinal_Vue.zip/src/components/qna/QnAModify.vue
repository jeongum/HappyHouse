<template>
  <div>
    <write-form type="modify" />
  </div>
</template>

<script>
import WriteForm from "@/components/qna/include/WriteForm.vue";

export default {
  name: "qnamodify",
  components: {
    WriteForm
  }
};
</script>
