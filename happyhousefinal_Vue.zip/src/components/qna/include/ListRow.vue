<template>
  <div>
    <b-table-simple class='text-center' hover>
      <b-thead>
        <tr>
          <b-th style="width:10%">번호</b-th>
          <b-th style="width: 20%">유형</b-th>
          <b-th>제목</b-th>
          <b-th style="width: 20%">글쓴이</b-th>
        </tr>
      </b-thead>
      <tr v-for="(qna, index) in paginatedData" :key="index">
        <b-td>{{ index + 1 }}</b-td>
        <b-td>[ {{qna.type}} ]</b-td>
        <b-td>
          <router-link
            :to="{ name: 'QnAView', params: { question_no: qna.question_no } }"
            >{{ qna.title }}</router-link
          >&nbsp;&nbsp;
          <b-badge class="new" v-if="isNew(qna.question_time)">new!</b-badge>
        </b-td>
        <b-td>{{ qna.username }}</b-td>
      </tr>
    </b-table-simple>

    <div class="btn-cover">
      <b-button :disabled="pageNum === 0" @click="prevPage" class="page-btn">
        이전
      </b-button>
      <span class="page-count">{{ pageNum + 1 }} / {{ pageCount }} 페이지</span>
      <b-button
        :disabled="pageNum >= pageCount - 1"
        @click="nextPage"
        class="page-btn"
      >
        다음
      </b-button>
    </div>
  </div>
</template>

<script>
export default {
  name: "paginated-list",
  data() {
    return {
      pageNum: 0,
    };
  },
  props: {
    listArray: {
      type: Array,
      required: true,
    },
    pageSize: {
      type: Number,
      required: false,
      default: 5,
    },
  },
  created() {
    // console.log("qnas!!!! " + this.paginatedData);
  },
  methods: {
    nextPage() {
      this.pageNum += 1;
    },
    prevPage() {
      this.pageNum -= 1;
    },
    isNew(someDate){
      const data = new Date(someDate);
      const today = new Date()
      return data.getDate() == today.getDate() &&
        data.getMonth() == today.getMonth() &&
        data.getFullYear() == today.getFullYear()
    }
  },
  computed: {
    pageCount() {
      let listLeng = this.listArray.length,
        listSize = this.pageSize,
        page = Math.floor(listLeng / listSize);
      if (listLeng % listSize > 0) page += 1;

      return page;
    },
    paginatedData() {
      const start = this.pageNum * this.pageSize,
        end = start + this.pageSize;
      return this.listArray.slice(start, end);
    },
  },
};
</script>

<style>
thead{
  background: #82ae46;
  color: #fff;
}
.btn-cover {
  margin-top: 1.5rem;
  text-align: center;
}
.btn-cover .page-btn {
  width: 5rem;
  height: 2rem;
  letter-spacing: 0.5px;
}
.btn-cover .page-count {
  padding: 0 1rem;
}
.new{
  background: #FFE400
}
</style>
