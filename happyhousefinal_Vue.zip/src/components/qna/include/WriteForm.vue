<template>
  <div>
    <div
      class="hero-wrap hero-bread"
      :style="{
        backgroundImage: 'url(' + require('@/assets/img/house3.jpg') + ')',
      }"
    >
      <div class="container">
        <div
          class="
            row
            no-gutters
            slider-text
            align-items-center
            justify-content-center
          "
        >
          <div class="col-md-9 ftco-animate text-center fadeInUp ftco-animated">
            <p class="breadcrumbs">
              <span class="mr-2"><a href="#">Home</a></span> <span>게시판</span>
            </p>
            <h1 class="mb-0 bread" v-if="type == 'create'">글 등록</h1>
            <h1 class="mb-0 bread" v-else>글 수정</h1>
          </div>
        </div>
      </div>
    </div>
    <b-container class="bv-example-row mt-5">
      <b-row class="mb-1">
        <b-col class="text-left">
          <b-form>
            <b-row class="mx-0">
              <b-button
                class="mr-2 type-btn"
                :class="{ select: typeSelected[0] }"
                @click="clickType(0, $event)"
                >친구해요</b-button
              >
              <b-button
                class="mr-2 type-btn"
                :class="{ select: typeSelected[1] }"
                @click="clickType(1, $event)"
                >중고거래</b-button
              >
              <b-button
                class="mr-2 type-btn"
                :class="{ select: typeSelected[2] }"
                @click="clickType(2, $event)"
                >동네홍보</b-button
              >
              <b-button
                class="mr-2 type-btn"
                :class="{ select: typeSelected[3] }"
                @click="clickType(3, $event)"
                >기타</b-button
              >
            </b-row>
            <b-form-input
              id="title"
              v-model="title"
              type="text"
              class="my-4"
              required
              placeholder="제목 입력..."
            />
            <b-form-textarea
              id="content"
              v-model="content"
              placeholder="내용 입력..."
              class="my-4"
              rows="10"
              max-rows="15"
            ></b-form-textarea>
            <b-row class="m-0" style="justify-content: right">
              <b-button
                v-if="type == 'create'"
                variant="primary"
                class="m-1"
                @click="checkValue"
                >등록</b-button
              >
              <b-button v-else variant="success" class="m-1" @click="checkValue"
                >수정</b-button
              >

              <b-button variant="primary" class="m-1" @click="moveList"
                >목록</b-button
              >
            </b-row>
          </b-form>
        </b-col>
      </b-row>
    </b-container>
  </div>
</template>

<script>
import { mapGetters, mapMutations, mapState } from "vuex";
import http from "@/util/http-common";
const memberStore = "memberStore";

export default {
  props: {
    type: String,
  },
  data() {
    return {
      question_no: "",
      question_type: "",
      title: "",
      username: "",
      content: "",
      typeSelected: [true, false, false, false],
    };
  },
  computed: {
    ...mapGetters(["qna"]),
    ...mapState(memberStore, ["userInfo"]),
  },
  created() {
    if (this.type == "modify") {
      this.$store.dispatch("getQnA", this.$route.params.question_no);
      this.question_type = this.qna.type;
      this.question_no = this.qna.question_no;
      this.title = this.qna.title;
      this.username = this.qna.username;
      this.content = this.qna.content;
    }
  },
  methods: {
    ...mapMutations(memberStore, ["SET_IS_LOGIN", "SET_USER_INFO"]),
    checkValue() {
      let err = true;
      let msg = "";
      err &&
        !this.title &&
        ((msg = "제목 입력해주세요"), (err = false), this.$refs.title.focus());

      err &&
        !this.content &&
        ((msg = "내용 입력해주세요"),
        (err = false),
        this.$refs.content.focus());

      if (!err) alert(msg);
      else this.type == "create" ? this.registQnA() : this.modifyQnA();
    },
    registQnA() {
      http
        .post("/question/", {
          type: this.question_type,
          title: this.title,
          username: this.userInfo.userName,
          content: this.content,
        })
        .then(({ data }) => {
          let msg = "등록 처리시 문제가 발생했습니다.";
          if (data === "success") {
            msg = "등록이 완료되었습니다.";
          }
          alert(msg);
          this.moveList();
        });
    },
    modifyQnA() {
      http
        .put(`/question/${this.question_no}`, {
          type: this.question_type,
          question_no: this.question_no,
          title: this.title,
          content: this.content,
        })
        .then(({ data }) => {
          let msg = "수정 처리시 문제가 발생했습니다.";
          if (data === "success") {
            msg = "수정이 완료되었습니다.";
          }
          alert(msg);
          this.moveList();
        });
    },
    moveList() {
      // this.$router.push("/qna/list");
      this.$router.push({ name: "QnAList" });
    },
    clickType(num, $event) {
      for (var i = 0; i < 4; i++) {
        this.$set(this.typeSelected, i, false);
        if (num == i) this.$set(this.typeSelected, i, true);
      }
      this.question_type = $event.target.innerText;
    },
  },
};
</script>
<style scoped>
.hero-wrap.hero-bread {
  padding: 10em 0;
}
.hero-wrap .slider-text .breadcrumbs {
  text-transform: uppercase;
  font-size: 12px;
  letter-spacing: 3px;
  margin-bottom: 0;
  z-index: 99;
  font-weight: 300;
}
.hero-wrap .slider-text .bread {
  font-weight: 800;
  color: #fff;
  font-size: 30px;
  font-family: "Poppins", Arial, sans-serif;
  letter-spacing: 3px;
  text-transform: uppercase;
}
.hero-wrap .slider-text .breadcrumbs span {
  color: #fff;
}
.type-btn {
  padding: 10px 20px;
  border: none;
}
.type-btn.select {
  background: #82ae46;
}
.btn.btn-primary:hover,
.btn.btn-primary:focus {
  background: #5b7931;
  border: 3px solid #5b7931;
}
</style>
