<template>
  <b-row v-if="this.modifyAnswer != null" class="mb-3 mt-2">
    <b-col cols="10">
      <b-form-textarea
        id="answer"
        placeholder="답변 입력..."
        v-model="modifyAnswer.answer"
        rows="2"
      ></b-form-textarea>
    </b-col>
    <b-col>
      <b-button variant="outline-info" class="mr-2 h-100" @click="updateAnswer"
        >수정</b-button
      >
      <b-button
        variant="outline-danger"
        class="h-100"
        @click="updateAnswerCancel"
        >취소</b-button
      >
    </b-col>
  </b-row>
  <b-row v-else class="mb-3 mt-2">
    <b-col cols="11">
      <b-form-textarea
        id="answer"
        placeholder="답변 입력..."
        v-model="answer"
        rows="2"
      ></b-form-textarea>
    </b-col>
    <b-col>
      <b-button variant="primary" class="h-100" @click="registAnswer"
        >등록</b-button
      >
    </b-col>
  </b-row>
</template>

<script>
import http from "@/util/http-common";
import { mapMutations, mapState } from "vuex";
const memberStore = "memberStore";

export default {
  name: "answerwrite",
  props: {
    question_no: Number,
    modifyAnswer: Object,
  },
  data() {
    return {
      username: "",
      answer: "",
    };
  },
  computed: {
    ...mapState(memberStore, ["userInfo"]),
  },
  methods: {
    ...mapMutations(memberStore, ["SET_IS_LOGIN", "SET_USER_INFO"]),
    registAnswer() {
      http
        .post("/answer/", {
          username: this.userInfo.userName,
          answer: this.answer,
          question_no: this.question_no,
        })
        .then(({ data }) => {
          let msg = "등록 처리시 문제가 발생했습니다.";
          if (data === "success") {
            msg = "등록이 완료되었습니다.";
          }
          alert(msg);
          this.answer = "";
          this.$store.dispatch("getAnswers", this.question_no);
        });
    },
    updateAnswer() {
      http
        .put(`/answer`, {
          answer_no: this.modifyAnswer.answer_no,
          answer: this.modifyAnswer.answer,
        })
        .then(({ data }) => {
          let msg = "수정 처리시 문제가 발생했습니다.";
          if (data === "success") {
            msg = "수정이 완료되었습니다.";
          }
          alert(msg);
          this.$store.dispatch("getAnswers", this.modifyAnswer.question_no);
          this.updateAnswerCancel();
        });
    },
    updateAnswerCancel() {
      this.$emit("modify-answer-cancel", false);
    },
  },
};
</script>

<style scoped>
.btn.btn-primary:hover, .btn.btn-primary:focus{
  background: #5b7931;
  border: 3px solid #5b7931
}  
</style>
