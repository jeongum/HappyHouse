<template>
  <b-container class="mb-2 p-4 answer-container">
    <b-row class="answer-contents">
      <b-col cols="2" class="text-left text-bold">
        <b-avatar
              variant="secondary"
              size="sm"
              v-text="answer.username.charAt(0)"
              class="mr-1"
        ></b-avatar
        >
        <b>{{ answer.username }}</b></b-col
      >
      <b-col cols="10" class="text-left">{{ enterToBr(answer.answer) }}</b-col>
    </b-row>
    <b-row class="answer-info">
      <b-col cols="2"></b-col>
      <b-col class="text-left" v-html="getFormatDate(answer.answer_time)"></b-col>
      <b-col class="text-right">
        <b-link @click="modifyAnswerView">수정</b-link> |
        <b-link @click="deleteAnswer">삭제</b-link>
      </b-col>
    </b-row>
    <!-- 로그인 기능 구현 후 로그인한 자신의 글에만 보이게 한다. -->
  </b-container>
</template>

<script>
import http from "@/util/http-common";
import moment from "moment";
import { mapMutations, mapState } from "vuex";
const memberStore = "memberStore";

export default {
  props: {
    answer: Object,
  },
  computed: {
    ...mapState(memberStore, ["userInfo"]),
  },
  created() {
    //console.log(this.answer);
  },
  methods: {
    ...mapMutations(memberStore, ["SET_IS_LOGIN", "SET_USER_INFO"]),
    modifyAnswerView() {
      //console.log("답변자 : " + this.answer.username);
      // console.log("로그인된 사람 : " + this.userInfo.userName);
      if (this.answer.username == this.userInfo.userName) {
        this.$emit("modify-answer", {
          answer_no: this.answer.answer_no,
          answer: this.answer.answer,
          question_no: this.answer.question_no,
        });
      } else {
        alert("답변자만 수정가능합니다!!");
      }
    },
    deleteAnswer() {
      if (this.answer.username == this.userInfo.userName) {
        if (confirm("삭제할까요?")) {
          http.delete(`/answer/${this.answer.answer_no}`).then(({ data }) => {
            let msg = "삭제 처리시 문제가 발생했습니다.";
            if (data === "success") {
              msg = "삭제가 완료되었습니다.";
            }
            alert(msg);
            this.$store.dispatch("getAnswers", this.answer.question_no);
          });
        }
      } else {
        alert("답변자만 삭제가능합니다!!");
      }
    },
    getFormatDate(regtime) {
      return moment(new Date(regtime)).format("YYYY.MM.DD HH:mm:ss");
    },
    enterToBr(str) {
      if (str) return str.replace(/(?:\r\n|\r|\n)/g, "<br />");
    },
  },
};
</script>

<style scoped>
.answer-container{
  border-radius: 5px;
  background: #f7f6f2;
}
.answer-contents{
  font-size: 18px;
  margin-bottom: 1rem;
}
.answer-info{
  font-size: 13px;
}
</style>
