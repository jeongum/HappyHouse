<template>
  <b-row class="mb-1">
    <b-col>
      <b-card> 
        <b-card-header>
          <div class=''>
            <h3 class='title text-center'>{{qna.title}}</h3>
          </div>
          <div class='row m-0'>
            <h6>{{qna.username}}</h6>
            <h6 class='ml-auto'>{{qna.question_time}}</h6>
          </div>
        </b-card-header>
        <b-card-body class="text-left">
          <div>
            <template v-for="(msg, index) in message"> {{ msg }}<br :key="index" /> </template>
          </div>
        </b-card-body>
      </b-card>
    </b-col>
  </b-row>
</template>

<script>
import { mapGetters } from "vuex";

export default {
  computed: {
    ...mapGetters(["qna"]),
    message() {
      // 상세설명부분 개행.
      if (this.qna.content) return this.qna.content.split("\n");
      return "";
    }
  },
  methods: {
    enterToBr(str) {
      if (str) return str.replace(/(?:\r\n|\r|\n)/g, "<br />");
    }
  }
};
</script>
<style scoped>
.card{
  border:none;
}
.card-header{
  border-top: 1px solid rgba(0, 0, 0, 0.125);
  background: white;
}
.card-header h6{
    font-weight: 600;
    color: rgba(0,0,0,0.5);
}
.card-header .title{
  font-weight: 800;
  font-size: 30px;
  font-family: "Poppins", Arial, sans-serif;
  letter-spacing: 3px;
}
</style>