<template>
<div>
  <div class="hero-wrap hero-bread" :style="{
      backgroundImage: 'url(' + require('@/assets/img/house3.jpg') + ')',
    }">
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center">
          <div class="col-md-9 text-center ">
            <p class="breadcrumbs"><span class="mr-2"><a href="#">Home</a></span> <span>게시판</span></p>
            <h1 class="mb-0 bread">자유 게시판</h1>
            <b-button class="btn btn-primary mt-3" pill @click="moveCreate">글 등록</b-button>
          </div>
        </div>
      </div>
  </div>
  <b-container class="bv-example-row mt-3">
    <div>
      <br />
      <ListRow :list-array="qnas"></ListRow>
    </div>
  </b-container>
</div>
</template>

<script>
import { mapGetters } from "vuex";
import ListRow from "@/components/qna/include/ListRow.vue";

export default {
  components: {
    ListRow,
  },
  computed: {
    ...mapGetters(["qnas"]),
  },
  created() {
    this.$store.dispatch("getQnAs");
  },
  methods: {
    moveCreate() {
      // this.$router.push("/qna/create");
      this.$router.push({ name: "QnACreate" });
    },
  },
};
</script>

<style scoped>
.hero-wrap.hero-bread {
    padding: 10em 0;
}
.hero-wrap .slider-text .breadcrumbs {
    text-transform: uppercase;
    font-size: 12px;
    letter-spacing: 3px;
    margin-bottom: 0;
    z-index: 99;
    font-weight: 300;
}
.hero-wrap .slider-text .bread {
    font-weight: 800;
    color: #fff;
    font-size: 30px;
    font-family: "Poppins", Arial, sans-serif;
    letter-spacing: 3px;
    text-transform: uppercase;
}
.hero-wrap .slider-text .breadcrumbs span {
    color: #fff;
}
thead{
  background: #82ae46;
  color: #fff;
}
.btn.btn-primary:hover, .btn.btn-primary:focus{
  background: #5b7931;
  border: 3px solid #5b7931
}  
</style>