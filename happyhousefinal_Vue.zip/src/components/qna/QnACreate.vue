<template>
  <div>
    <write-form type="create" />
  </div>
</template>

<script>
import WriteForm from "@/components/qna/include/WriteForm.vue";

export default {
  components: {
    WriteForm
  }
};
</script>

