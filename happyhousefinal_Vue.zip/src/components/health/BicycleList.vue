<template>
<div>
    <div class="hero-wrap hero-bread" :style="{
      backgroundImage: 'url(' + require('@/assets/img/house3.jpg') + ')',
    }">
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center">
          <div class="col-md-9 ftco-animate text-center fadeInUp ftco-animated">
            <p class="breadcrumbs"><span class="mr-2"><a href="#">Home</a></span> <span>Health</span></p>
            <h1 class="mb-0 bread">내주변따릉이</h1>
          </div>
        </div>
      </div>
  </div>
  <b-container class="bv-example-row" style="padding: 5rem 0; position: relative">
    <div class="info-overlay">
        <b-card :title="title">
            <b-table-simple striped>
                <b-tr>
                    <b-th style="width:30%">주소</b-th>
                    <b-td>{{address}}</b-td>
                </b-tr>
                <b-tr>
                    <b-th>타입</b-th>
                    <b-td>{{type}}</b-td>
                </b-tr>
                <b-tr>
                    <b-th>대수</b-th>
                    <b-td>{{cnt}} 대</b-td>
                </b-tr>
            </b-table-simple>
            <a id="create-kakao-link-btn" @click="sendkakao" >
                <img
                    src="https://developers.kakao.com/assets/img/about/logos/kakaolink/kakaolink_btn_medium.png" style="width: 40px"
                />&nbsp;&nbsp;카카오톡 공유하기
            </a>
        </b-card>
    </div>
    <div id="map" style="width:100%;height:600px;"></div>
  </b-container>
</div>
</template>

<script>
import { mapState } from 'vuex';
export default {
    data(){
        return{
            address: null,
            title: null,
            type: null,
            cnt: null,
        }
    },
    computed:{
        ...mapState(["bicycles", "sido", "gugun"])
    },
    mounted() {
        if (window.kakao && window.kakao.maps) {
            this.initMap();
        } else {
            const script = document.createElement("script");
            /* global kakao */
            script.onload = () => kakao.maps.load(this.initMap);
            script.src =
                "//dapi.kakao.com/v2/maps/sdk.js?autoload=false&appkey=915cffed372954b7b44804ed422b9cf0&libraries=services";
            document.head.appendChild(script);
        }
    },
    methods:{
        initMap(){
            var imageSrc = "https://t1.daumcdn.net/localimg/localimages/07/mapapidoc/markerStar.png"; 

            var mapContainer = document.getElementById('map'), // 지도를 표시할 div  
            pos = this.getGuPos(),
            mapOption = { 
                center: (pos)?new kakao.maps.LatLng(pos.lat, pos.lng):new kakao.maps.LatLng(37.566826, 126.9786567),
                level: 3 // 지도의 확대 레벨
            };

            var map = new kakao.maps.Map(mapContainer, mapOption); // 지도를 생성합니다
            for (var i = 0; i < this.bicycles.length; i ++) {
                // 마커 이미지의 이미지 크기 입니다
                var imageSize = new kakao.maps.Size(24, 35); 
                
                // 마커 이미지를 생성합니다    
                var markerImage = new kakao.maps.MarkerImage(imageSrc, imageSize); 
                
                // 마커를 생성합니다
                var marker = new kakao.maps.Marker({
                    map: map, // 마커를 표시할 지도
                    position: new kakao.maps.LatLng(this.bicycles[i].lat, this.bicycles[i].lng), // 마커를 표시할 위치
                    image : markerImage // 마커 이미지 
                });
                kakao.maps.event.addListener(marker, 'click', this.makeClickListener(this.bicycles[i]));
            }
        },
        getGuPos(){
            for (var i = 0; i < this.bicycles.length; i ++) {
                if(this.bicycles[i].gu == this.gugun.name){
                    return this.bicycles[i];
                }
            }
            return null
        },
        makeClickListener(data) {
            return function() {
                this.title = data.place;
                this.address = data.address;
                this.type = data.type;
                if(this.type == "QR"){
                    this.cnt = data.qrCnt;
                }else{
                    this.cnt = data.lcdCnt;
                }
                console.log(this.title);
            }.bind(this);
        },
        sendkakao(){
            window.Kakao.Link.createDefaultButton({
                container: '#create-kakao-link-btn',
                objectType: 'location',
                address: this.address,
                addressTitle: this.title,
                content: {
                title: '여기에 따릉이가 있어요!',
                description: '이 지역에 따릉이가 '+this.cnt+'개 남았어요!',
                imageUrl:
                    'https://mblogthumb-phinf.pstatic.net/20151021_218/mobuu_1445435069321gvB3G_JPEG/2015090302531_1.jpg?type=w2',
                link: {
                    mobileWebUrl: 'https://developers.kakao.com',
                    webUrl: 'https://developers.kakao.com',
                },
                },
                buttons: [
                {
                    title: '웹으로 보기',
                    link: {
                    mobileWebUrl: 'https://developers.kakao.com',
                    webUrl: 'https://developers.kakao.com',
                    },
                },
                ],
            })
        }
    }
}
</script>

<style scoped>
.info-overlay{
    position: absolute;
    z-index: 2;
    background: rgba(255,255,255,0.8);
    width: 20%;
    top: 25%;
    left: 1%;
    border-radius: 10px;
}
.row{
  margin: 15px 0;
}
.hero-wrap.hero-bread {
    padding: 10em 0;
}
.hero-wrap .slider-text .breadcrumbs {
    text-transform: uppercase;
    font-size: 12px;
    letter-spacing: 3px;
    margin-bottom: 0;
    z-index: 99;
    font-weight: 300;
}
.bread {
    font-weight: 800;
    color: #fff;
    font-size: 30px;
    font-family: "Poppins", Arial, sans-serif;
    letter-spacing: 3px;
    text-transform: uppercase;
}
.hero-wrap .slider-text .breadcrumbs span {
    color: #fff;
}
table{
  text-align: center;
}
.subheading {
    font-size: 18px;
    display: block;
    margin-bottom: 10px;
    font-family: "Lora", Georgia, serif;
    font-style: italic;
    color: #82ae46;
}
thead{
  background: #82ae46;
  color: #fff;
}
.card{
    background-color: transparent;
    border: none;
    font-size: 14px;
}
.card-title{
    font-weight: 800;
    font-size: 20px;
    font-family: "Poppins", Arial, sans-serif;
    letter-spacing: 3px;
}
</style>