<script>
import { Line } from 'vue-chartjs'
import {  mapState } from "vuex";
export default {
  computed: {
    ...mapState(["aptRealPrcs"]),
  },
  data() { 
    return{
      sellings: [],
      rent: []
    }
  },
  extends: Line,
  created(){
    this.setChartData(this.aptRealPrcs);
  },
  mounted () {
    this.renderChart({
      labels: ['1월', '2월', '3월', '4월', '5월', '6월', '7월', '8월', '9월'],
      datasets: [
        {
          label: '매매가',
          backgroundColor: 'rgba(71,183,132,.5)',
          borderColor: '#47b784',
          data: Array.from(this.sellings)
        },
        {
          label: '전세가',
          backgroundColor: 'rgba(54,73,93,.5)',
          borderColor: '#36495d',
          data: Array.from(this.rent)
        }
      ],
      }, {responsive: true, maintainAspectRatio: false}
    )
  },
  methods: {
    setChartData: function(data){
      for(var i =0 ; i < data.length ; i++){
        if(data[i].contracttype=="매매"){
          this.sellings.push(data[i].jan);
          this.sellings.push(data[i].feb);
          this.sellings.push(data[i].mar);
          this.sellings.push(data[i].apr);
          this.sellings.push(data[i].may);
          this.sellings.push(data[i].jun);
          this.sellings.push(data[i].jul);
          this.sellings.push(data[i].aug);
          this.sellings.push(data[i].sep);
        }
        else{
          this.rent.push(data[i].jan);
          this.rent.push(data[i].feb);
          this.rent.push(data[i].mar);
          this.rent.push(data[i].apr);
          this.rent.push(data[i].may);
          this.rent.push(data[i].jun);
          this.rent.push(data[i].jul);
          this.rent.push(data[i].aug);
          this.rent.push(data[i].sep);
        }
      }
    },
  },
}
</script>
