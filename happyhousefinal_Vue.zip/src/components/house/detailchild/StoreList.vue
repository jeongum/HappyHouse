<template>
  <div>
    <div>
      <b-card no-body>
        <b-card-text>
              <b-table-simple hover responsive class="text-center">
                <b-thead>
                  <b-tr>
                    <b-th style="width:30%">상호명</b-th>
                    <b-th style="width:35%">주소</b-th>
                    <b-th style="width:35%">찾아가기</b-th>
                  </b-tr>
                </b-thead>
                <b-tbody>
                  <b-tr v-for="(store, index) in stores" :key="index" :store="store" @click="clickStore(store)">
                    <b-td>{{store.place_name}}</b-td>
                    <b-td>{{store.address_name}}</b-td>
                    <b-td><a :href="store.place_url" target="_blank" >{{store.place_url}}</a></b-td>
                  </b-tr>
                </b-tbody>
              </b-table-simple>
          </b-card-text>
      </b-card>
    </div>
  </div>
</template>

<script>
import { eventBus } from "@/main.js";
export default {
  data(){
    return{
      stores: [],
    }
  },
  created(){
    eventBus.$on("placeData", (payload)=>{
      this.stores = payload;
    })
  },
  methods: {
  
  }
}
</script>

<style>

</style>