<template>
<div>
  <div class="hero-wrap hero-bread" :style="{
      backgroundImage: 'url(' + require('@/assets/img/house3.jpg') + ')',
    }">
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center">
          <div class="col-md-9 ftco-animate text-center fadeInUp ftco-animated">
            <p class="breadcrumbs"><span class="mr-2"><a href="#">Home</a></span> <span>거래정보</span></p>
            <h1 class="mb-0 bread">거래정보</h1>
          </div>
        </div>
      </div>
  </div>
  <b-container class="bv-example-row mt-3 text-center">
    <b-row>
      <b-container v-if="houses && houses.length != 0" class="bv-example-row mt-3">
        <b-table-simple hover responsive>
          <b-thead>
            <b-tr>
              <b-th>일련번호</b-th>
              <b-th>아파트</b-th>
              <b-th>동</b-th>
              <b-th>거래금액<span style="font-size:10px">(단위: 만원)</span></b-th>
            </b-tr>
          </b-thead>
          <tbody>
            <!-- 하위 component인 ListRow에 데이터 전달(props) -->
            <house-list-row
              v-for="(house, index) in houses"
              :key="index"
              :house="house"
            />
          </tbody>
        </b-table-simple>
      </b-container>
      <b-container v-else class="bv-example-row mt-3">
        <b-row>
          <b-col><b-alert show>주택 목록이 없습니다.</b-alert></b-col>
        </b-row>
      </b-container>
    </b-row>
  </b-container>
</div>
</template>

<script>
import HouseListRow from "@/components/house/HouseListRow.vue";
import { mapState, mapActions } from "vuex";

export default {
  components: {
    HouseListRow,
  },
  data() {
    return {
    };
  },
  created() {
    this.getHouseList(this.gugun.code);
  },
  computed: {
    ...mapState(["houses","gugun","sido"]),
  },
  methods: {
    ...mapActions(["getHouseList"]),
  },
};
</script>

<style scoped>
.hero-wrap.hero-bread {
    padding: 10em 0;
}
.hero-wrap .slider-text .breadcrumbs {
    text-transform: uppercase;
    font-size: 12px;
    letter-spacing: 3px;
    margin-bottom: 0;
    z-index: 99;
    font-weight: 300;
}
.hero-wrap .slider-text .bread {
    font-weight: 800;
    color: #fff;
    font-size: 30px;
    font-family: "Poppins", Arial, sans-serif;
    letter-spacing: 3px;
    text-transform: uppercase;
}
.hero-wrap .slider-text .breadcrumbs span {
    color: #fff;
}
thead{
  background: #82ae46;
  color: #fff;
}
</style>
