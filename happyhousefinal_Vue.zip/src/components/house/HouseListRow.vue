<template>
  <b-tr
    class="m-2"
    @click="selectHouse"
    @mouseover="colorChange(true)"
    @mouseout="colorChange(false)"
    :class="{ 'mouse-over-bgcolor': isColor }"
  >
    <b-td class="text-center align-self-center">
      {{ house.일련번호 }}
    </b-td>
    <b-td class="align-self-center">
      {{ house.아파트 }}
    </b-td>
    <b-td class="text-center align-self-center">
      {{ house.법정동 }}
    </b-td>
    <b-td class="text-center align-self-center">
      {{ house.거래금액 }}
    </b-td>
  </b-tr>
</template>

<script>
import { mapActions, mapState } from "vuex";
export default {
  name: "HouseListRow",
  computed:{
    ...mapState(["sido"]),
  },
  data() {
    return {
      isColor: false,
    };
  },
  props: {
    house: Object,
  },
  methods: {
    ...mapActions(["detailHouse","getAptRealPrc"]),
    colorChange(flag) {
      this.isColor = flag;
    },
    selectHouse() {
      this.detailHouse(this.house);
      this.getAptRealPrc(this.sido.code);
      this.$router.push('detail');
    },
  },
};
</script>

<style scoped>
.apt {
  width: 50px;
}
.mouse-over-bgcolor {
  background-color: lightblue;
}
</style>
