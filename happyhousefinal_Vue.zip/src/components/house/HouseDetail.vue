<template>
<div>
  <div class="hero-wrap hero-bread" :style="{
      backgroundImage: 'url(' + require('@/assets/img/house3.jpg') + ')',
    }">
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center">
          <div class="col-md-9 ftco-animate text-center fadeInUp ftco-animated">
            <p class="breadcrumbs"><span class="mr-2"><a href="#">Home</a></span> <span>거래정보</span></p>
            <h1 class="mb-0 bread">{{ house.아파트 }}</h1>
          </div>
        </div>
      </div>
  </div>
  <b-container class="bv-example-row" style="padding:5rem 0">
    <b-row>
      <b-col cols="6">
        <img :src="require('@/assets/img/apt/'+aptImg+'.jpg')" style="width:100%"/>
      </b-col>
      <b-col>
        <b-table-simple responsive>
          <b-tbody>
            <b-tr>
              <b-th>일련번호</b-th>
              <b-td>{{house.일련번호}}</b-td>
            </b-tr>
            <b-tr>
              <b-th>아파트</b-th>
              <b-td>{{house.아파트}}</b-td>
            </b-tr>
            <b-tr>
              <b-th>법정동</b-th>
              <b-td>{{house.법정동}}</b-td>
            </b-tr>
            <b-tr>
              <b-th>도로명주소</b-th>
              <b-td>{{house.도로명}}</b-td>
            </b-tr>
            <b-tr>
              <b-th>건축년도</b-th>
              <b-td>{{house.건축년도}}</b-td>
            </b-tr>
            <b-tr>
              <b-th>전용면적</b-th>
              <b-td>{{house.전용면적}}</b-td>
            </b-tr>
            <b-tr>
              <b-th>거래금액</b-th>
              <b-td>{{
                (parseInt(house.거래금액.replace(",", "")) * 10000) | price
              }}원</b-td>
            </b-tr>
          </b-tbody>
        </b-table-simple>
      </b-col>
    </b-row>
    <hr>
    <div class="justify-content-center text-center">
      <span class="subheading">CHART</span>
      <h1 class="mb-0 bread" style="color:#000">아파트 실거래 가격 지수</h1>
    </div>
    <b-row>
       <b-col>
        <apt-real-prc></apt-real-prc>
      </b-col>
    </b-row>
    <hr>
    <div class="justify-content-center text-center">
      <span class="subheading">MAP</span>
      <h1 class="mb-0 bread" style="color:#000">주변 상가 정보</h1>
    </div>
    <b-row>
      <b-col>
        <kakao-map></kakao-map>
      </b-col>
    </b-row>
    <b-row>
      <b-col>
        <store-list></store-list>
      </b-col>
    </b-row>  
  </b-container>
</div>
</template>

<script>
import {   mapState } from "vuex";
import AptRealPrc from './detailchild/AptRealPrc.vue';
import KakaoMap from './detailchild/KakaoMap.vue';
import StoreList from './detailchild/StoreList.vue';

export default {
  components: { AptRealPrc, StoreList, KakaoMap },
  computed: {
    ...mapState(["house", "sido"]),
  },
  filters: {
    price(value) {
      if (!value) return value;
      return value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    },
  },
  data() { 
    return{
      aptImg: null,
    }
  },
  created() {
    this.aptImg = Math.floor(Math.random() * 5)+1;
  },
  methods: {
    setAptImg(){
      // const rand = Math.floor(Math.random() * 5)+1;
      return 'require("@/assets/img/apt/'+Math.floor(Math.random() * 5)+1+'.jpg")';
    }
  },
};
</script>

<style scoped>
.row{
  margin: 15px 0;
}
.hero-wrap.hero-bread {
    padding: 10em 0;
}
.hero-wrap .slider-text .breadcrumbs {
    text-transform: uppercase;
    font-size: 12px;
    letter-spacing: 3px;
    margin-bottom: 0;
    z-index: 99;
    font-weight: 300;
}
.bread {
    font-weight: 800;
    color: #fff;
    font-size: 30px;
    font-family: "Poppins", Arial, sans-serif;
    letter-spacing: 3px;
    text-transform: uppercase;
}
.hero-wrap .slider-text .breadcrumbs span {
    color: #fff;
}
table{
  text-align: center;
}
.subheading {
    font-size: 18px;
    display: block;
    margin-bottom: 10px;
    font-family: "Lora", Georgia, serif;
    font-style: italic;
    color: #82ae46;
}
thead{
  background: #82ae46;
  color: #fff;
}
</style>
