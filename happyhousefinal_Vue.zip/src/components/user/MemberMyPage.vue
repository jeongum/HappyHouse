<template>
  <b-container>
      <div class="wrap">
      <div class="form-wrap">
        <div class="text-center">
          <button type="button" class="togglebtn">
            내 정보
          </button>
        </div>
        <b-form class="text-left">
          <b-row>
            <label>이름</label>
            <input
                type="text"
                class="input-field"
                id="userName"
                name="userName"
                :value="userInfo.userName"
                readonly
              />
          </b-row>
          <b-row>
            <label>아이디</label>
            <input
              type="text"
              class="input-field"
              id="userId"
              name="userId"
              :value="userInfo.userId"
              readonly
            />
          </b-row>
          <b-row>
            <label>이메일</label>
            <input
                type="text"
                class="input-field"
                :value="userInfo.email"
                readonly
              />
          </b-row>
          <b-row>
            <label>가입일</label>
            <input
                type="text"
                class="input-field"
                :value="userInfo.joinDate"
                readonly
              />
          </b-row> 
          <br /><br />
          <b-button class="under-btn" id="submitbtn" type="button" @click="moveModifyUserInfo"
            >수정</b-button
          >
        </b-form>
      </div>
    </div>
  </b-container>
</template>

<script>
import { mapState, mapMutations } from "vuex";
import http from "@/util/http-common";

const memberStore = "memberStore";

export default {
  name: "MemberMyPage",
  components: {},
  computed: {
    ...mapState(memberStore, ["userInfo"]),
  },
  methods: {
    ...mapMutations(memberStore, ["SET_IS_LOGIN", "SET_USER_INFO"]),
    moveIndex() {
      this.$router.push({ name: "Home" });
    },
    moveModifyUserInfo() {
      this.$router.replace({
        name: "UserUpdate",
        params: { userId: this.userInfo.userId },
      });
    },
    removeUserInfo() {
      if (confirm("정말로 탈퇴하시겠습니까?")) {
        http.delete(`/user/${this.userInfo.userId}`).then(({ data }) => {
          let msg = "삭제 처리시 문제가 발생했습니다.";
          if (data === "success") {
            msg = "삭제가 완료되었습니다.";
          }
          this.SET_IS_LOGIN(false);
          this.SET_USER_INFO(null);
          sessionStorage.removeItem("access-token");
          alert(msg);

          this.$router.push({ name: "Home" });
        });
      }
    },
  },
};
</script>

<style scoped>
* {
  margin: 0;
  padding: 0;
  font-family: sans-serif;
}
.wrap {
  height: 100%;
  width: 100%;
  background-position: center;
  background-size: cover;
  position: absolute;
  background-image: url("~@/assets/img/house1.jpg");
}
.form-wrap {
  width: 380px;
  height: 480px;
  position: relative;
  margin: 6% auto;
  padding: 40px;
  background: #f7f6f2;
  overflow: hidden;
}
.togglebtn {
  padding: 10px 25px;
  cursor: pointer;
  background: linear-gradient(to right, #82ae46, #faca6a);;
  border-radius: 30px;
  border: 0;
  outline: none;
  position: relative;
  color: white;
}
form{
  margin-top: 20px;
}
#pwdfind {
  text-align: left;
  font-size: 2px;
  font-style: italic;
  color: #777;
  font: italic bold;
}
.input-group {
  top: 100px;
  position: absolute;
  width: 280px;
  transition: 0.5s;
}
.input-field {
  width: 80%;
  padding: 10px 0;
  margin: 10px 0;
  border: none;
  border-bottom: 1px solid #999;
  outline: none;
  background: transparent;
}
label{
    width: 20%;
    padding: 10px 0;
    margin: 10px 0;
    font-weight: 600;
}
.under-btn {
  width: 45%;
  padding: 10px 30px;
  cursor: pointer;
  display: block;
  margin: auto;
  background: linear-gradient(to right, #03c273, #faca6a);
  border: 0;
  outline: none;
  border-radius: 30px;
}
#resetBtn{
  background: white;
}
</style>
