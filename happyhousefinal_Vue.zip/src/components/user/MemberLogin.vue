<template>
  <b-container>
    <div class="wrap">
      <div class="form-wrap">
        <div class="text-center">
          <button type="button" class="togglebtn">Login</button>
        </div>

        <b-form class="text-left">
          <input
            type="text"
            class="input-field"
            placeholder="아이디"
            v-model="user.userId"
            required
          />
          <input
            type="password"
            class="input-field"
            placeholder="비밀번호"
            v-model="user.userPwd"
            required
          />
          <a href="#" @click="moveSignUp" id="singup"><span>회원가입</span></a>
          <br />
          <a href="#" @click="moveFindPwd" id="pwdfind"
            ><span>비밀번호 찾기</span></a
          >
          <br /><br /><br />

          <b-button type="button" id="submitbtn" @click="confirm"
            >로그인</b-button
          >
        </b-form>
      </div>
    </div>
  </b-container>
</template>

<script>
import { mapState, mapActions, mapMutations } from "vuex";

const memberStore = "memberStore";

export default {
  name: "MemberLogin",
  data() {
    return {
      user: {
        userId: null,
        userPwd: null,
      },
    };
  },
  computed: {
    ...mapState(memberStore, ["isLogin", "isLoginError", "userInfo"]),
  },
  methods: {
    ...mapActions(memberStore, ["userConfirm", "getUserInfo"]),
    ...mapMutations(["SET_SIDO", "SET_GUGUN"]),
    async confirm() {
      await this.userConfirm(this.user);
      let token = sessionStorage.getItem("access-token");
      if (this.isLogin) {
        await this.getUserInfo(token);
        this.$router.push({ name: "Home" });
      }
    },
    movePage() {
      this.$router.push({ name: "SignUp" });
    },
    moveFindPwd() {
      this.$router.push({ name: "FindPwd" });
    },
    moveSignUp() {
      this.$router.push({ name: "SignUp" });
    },
  },
};
</script>

<style scoped>
* {
  margin: 0;
  padding: 0;
  font-family: sans-serif;
}
.wrap {
  height: 100%;
  width: 100%;
  background-position: center;
  background-size: cover;
  position: absolute;
  background-image: url("~@/assets/img/house1.jpg");
}
.form-wrap {
  width: 380px;
  height: 480px;
  position: relative;
  margin: 6% auto;
  padding: 40px;
  background: #f7f6f2;
  overflow: hidden;
}
.togglebtn {
  padding: 10px 25px;
  cursor: pointer;
  background: linear-gradient(to right, #82ae46, #faca6a);
  border-radius: 30px;
  border: 0;
  outline: none;
  position: relative;
  color: white;
}
form {
  margin-top: 80px;
}
#singup {
  text-align: left;
  font-size: 2px;
  font-style: italic;
  color: #777;
  font: italic bold;
}
#pwdfind {
  text-align: right;
  font-size: 2px;
  font-style: italic;
  color: #777;
  font: italic bold;
}
.input-group {
  top: 100px;
  position: absolute;
  width: 280px;
  transition: 0.5s;
}
.input-field {
  width: 100%;
  padding: 10px 0;
  margin: 15px 0;
  border: none;
  border-bottom: 1px solid #999;
  outline: none;
  background: transparent;
}
#submitbtn {
  width: 85%;
  padding: 10px 30px;
  cursor: pointer;
  display: block;
  margin: auto;
  background: linear-gradient(to right, #03c273, #faca6a);
  border: 0;
  outline: none;
  border-radius: 30px;
}
</style>
