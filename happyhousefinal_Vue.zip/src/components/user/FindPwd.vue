<template>
<b-container>
  <div class="wrap">
      <div class="form-wrap">
        <div class="text-center">
          <button type="button" class="togglebtn">
            비밀번호 찾기
          </button>
        </div>
        <b-row class="info">등록하신 이메일로 임시 비밀번호를 발급해드립니다.</b-row>
        <b-form class="text-left">
          <b-row>
            <label>아이디</label>
            <input
              type="text"
              class="input-field"
              id="userId"
              name="userId"
              v-model="userId"
            />
          </b-row>
          <b-row>
            <label>이메일</label>
            <input
                type="text"
                class="input-field"
                v-model="email"
              />
          </b-row>
          <br /><br /><br />
          <b-button class="under-btn" id="submitbtn" type="button" @click="sendEmail"
            >재발급</b-button
          >
        </b-form>
      </div>
  </div>
</b-container>
</template>

<script>
import http from "@/util/http-common";

export default {
  data() {
    return {
      userId: null,
      email: null,
    };
  },
  methods: {
    sendEmail() {
      if (!this.userId || !this.email) {
        alert("입력이 잘못되었습니다 !");
      } else {
        http
          .get(`/user/send/`, {
            params: { userId: this.userId, email: this.email },
          })
          .then(({ data }) => {
            if (data === "success") {
              alert("가입된 이메일로 비밀번호를 발송했습니다 !");
              this.$router.push({ name: "SignIn" });
            } else {
              alert(
                "이메일 발송을 실패했습니다. 아이디와 이메일주소를 다시한번 확인하세요 !"
              );
            }
          });
      }
    },
  },
};
</script>

<style scoped>
* {
  margin: 0;
  padding: 0;
  font-family: sans-serif;
}
.wrap {
  height: 100%;
  width: 100%;
  background-position: center;
  background-size: cover;
  position: absolute;
  background-image: url("~@/assets/img/house1.jpg");
}
.form-wrap {
  width: 380px;
  height: 480px;
  position: relative;
  margin: 6% auto;
  padding: 40px;
  background: #f7f6f2;
  overflow: hidden;
}
.togglebtn {
  padding: 10px 25px;
  cursor: pointer;
  background: linear-gradient(to right, #82ae46, #faca6a);;
  border-radius: 30px;
  border: 0;
  outline: none;
  position: relative;
  color: white;
}
form{
  margin-top: 40px;
}
#pwdfind {
  text-align: left;
  font-size: 2px;
  font-style: italic;
  color: #777;
  font: italic bold;
}
.input-group {
  top: 100px;
  position: absolute;
  width: 280px;
  transition: 0.5s;
}
.input-field {
  width: 80%;
  padding: 10px 0;
  margin: 10px 0;
  border: none;
  border-bottom: 1px solid #999;
  outline: none;
  background: transparent;
}
label{
    width: 20%;
    padding: 10px 0;
    margin: 10px 0;
    font-weight: 600;
}
.under-btn {
  width: 45%;
  padding: 10px 30px;
  cursor: pointer;
  display: block;
  margin: auto;
  background: linear-gradient(to right, #03c273, #faca6a);
  border: 0;
  outline: none;
  border-radius: 30px;
}
#resetBtn{
  background: white;
}
.info{
  font-size: 12px;
    margin-top: 40px;
}
</style>
