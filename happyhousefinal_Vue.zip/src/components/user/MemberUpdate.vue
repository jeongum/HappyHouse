<template>
  <b-container>
      <div class="wrap">
      <div class="form-wrap">
        <div class="text-center">
          <button type="button" class="togglebtn">
            내 정보
          </button>
        </div>
        <b-form class="text-left">
          <b-row>
            <label>이름</label>
            <input
                type="text"
                class="input-field"
                id="userName"
                name="userName"
                v-model="userInfo.userName"
                
              />
          </b-row>
          <b-row>
            <label>아이디</label>
            <input
              type="text"
              class="input-field"
              id="userId"
              name="userId"
              v-model="userInfo.userId"
              readonly
            />
          </b-row>
          <b-row>
            <label>이메일</label>
            <input
                type="text"
                class="input-field"
                v-model="userInfo.email"
                
              />
          </b-row>
          <b-row>
            <label>비밀번호</label>
            <input
              type="password"
              id="userPwd"
              name="userPwd"
              class="input-field"
              placeholder="비밀번호"
              v-model="userInfo.userPwd"
              
            />
          </b-row> 
          <br /><br /><br />
          <b-row>
          <b-button class="under-btn" id="submitbtn" type="button" @click="updateUserInfo"
            >수정하기</b-button
          >
          <button class="under-btn" id="resetBtn" type="button" @click="moveMyPage">취소</button>
          </b-row>
        </b-form>
      </div>
    </div>
  </b-container>
</template>

<script>
import { mapState } from "vuex";
import http from "@/util/http-common";

const memberStore = "memberStore";

export default {
  data() {
    return {};
  },
  components: {},
  computed: {
    ...mapState(memberStore, ["userInfo"]),
  },
  methods: {
    moveMyPage() {
      this.$router.push({ name: "MyPage" });
    },
    updateUserInfo() {
      // alert("수정!  " + this.userInfo);
      //userInfo.userPwd가 비어있지 않을떄 ?
      if (!this.userInfo.userPwd) {
        alert("수정할 비밀번호를 입력하세요 !");
      } else {
        http.put(`/user/`, this.userInfo).then(({ data }) => {
          let msg = "수정 처리시 문제가 발생했습니다.";
          if (data === "success") {
            msg = "수정이 완료되었습니다.";
          }
          alert(msg);
          this.$router.push({ name: "MyPage" });
        });
      }
    },
  },
};
</script>

<style scoped>
* {
  margin: 0;
  padding: 0;
  font-family: sans-serif;
}
.wrap {
  height: 100%;
  width: 100%;
  background-position: center;
  background-size: cover;
  position: absolute;
  background-image: url("~@/assets/img/house1.jpg");
}
.form-wrap {
  width: 380px;
  height: 560px;
  position: relative;
  margin: 6% auto;
  padding: 40px;
  background: #f7f6f2;
  overflow: hidden;
}
.togglebtn {
  padding: 10px 25px;
  cursor: pointer;
  background: linear-gradient(to right, #82ae46, #faca6a);;
  border-radius: 30px;
  border: 0;
  outline: none;
  position: relative;
  color: white;
}
form{
  margin-top: 20px;
}
#pwdfind {
  text-align: left;
  font-size: 2px;
  font-style: italic;
  color: #777;
  font: italic bold;
}
.input-group {
  top: 100px;
  position: absolute;
  width: 280px;
  transition: 0.5s;
}
.input-field {
  width: 75%;
  padding: 10px 0;
  margin: 10px 0;
  border: none;
  border-bottom: 1px solid #999;
  outline: none;
  background: transparent;
}
label{
    width: 25%;
    padding: 10px 0;
    margin: 10px 0;
    font-weight: 600;
}
.under-btn {
  width: 45%;
  padding: 10px 30px;
  cursor: pointer;
  display: block;
  margin: auto;
  background: linear-gradient(to right, #03c273, #faca6a);
  border: 0;
  outline: none;
  border-radius: 30px;
}
#resetBtn{
  background: white;
}
</style>
