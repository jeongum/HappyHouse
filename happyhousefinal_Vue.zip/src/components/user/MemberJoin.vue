<template>
  <b-container>
    <div class="wrap">
      <div class="form-wrap">
        <div class="text-center">
          <button type="button" class="togglebtn">Join</button>
        </div>
        <b-form class="text-left">
          <input
            type="text"
            class="input-field"
            id="userName"
            name="userName"
            v-model="userName"
            placeholder="이름입력"
          />
          <input
            type="text"
            class="input-field"
            id="userId"
            name="userId"
            v-model="userId"
            @keyup="idcheck"
            placeholder="아이디입력"
          />
          <div class="mt-1" style="font-size: 10px">{{ idresult }}</div>
          <input
            type="password"
            class="input-field"
            id="userPwd"
            name="userPwd"
            v-model="userPwd"
            placeholder="비밀번호입력"
          />
          <input
            type="password"
            class="input-field"
            id="pwdcheck"
            name="pwdcheck"
            v-model="pwdcheck"
            placeholder="비밀번호재입력"
          />
          <input
            type="text"
            class="input-field"
            v-model="email"
            placeholder="이메일입력"
          />

          <br /><br /><br />
          <b-row>
            <b-button
              class="under-btn"
              id="submitbtn"
              type="button"
              @click="checkValue"
              >회원가입</b-button
            >
            <button class="under-btn" id="resetBtn" type="reset">초기화</button>
          </b-row>
        </b-form>
      </div>
    </div>
  </b-container>
</template>

<script>
import http from "@/util/http-common";

export default {
  name: "MemberJoin",
  data() {
    return {
      userName: "",
      userId: "",
      email: "",
      userPwd: "",
      pwdcheck: "",
      isId: false,
      isPwd: false,
      idresult: "",
    };
  },
  computed: {},
  methods: {
    idcheck() {
      //console.log(this.userId.length);
      if (this.userId.length < 4 || this.userId.length > 16) {
        this.idresult = "아이디는 4자 이상 16자 이하입니다.";
      } else {
        http.get(`/user/idcheck/${this.userId}`).then(({ data }) => {
          if (data === "success") {
            this.idresult = "사용가능한 아이디입니다!";
            this.isId = true;
          } else {
            this.idresult = "중복된 아이디입니다! 다른 아이디를 이용하세요";
            this.isId = false;
          }
        });
      }
    },
    checkValue() {
      let err = true;
      let msg = "";
      err && !this.userName && ((msg = "이름을 입력해주세요"), (err = false));

      err &&
        !this.userPwd &&
        !this.pwdcheck &&
        ((msg = "비밀번호를 확인 해주세요"), (err = false));

      err &&
        this.userPwd != this.pwdcheck &&
        ((msg = "비밀번호가 다릅니다. 다시 확인 해주세요"), (err = false));

      err && !this.email && ((msg = "이메일을 입력해주세요"), (err = false));

      err && !this.isId && ((msg = "아이디를 확인해주세요"), (err = false));

      if (!err) alert(msg);
      else this.registMember();
    },
    registMember() {
      http
        .post("/user/", {
          userName: this.userName,
          userId: this.userId,
          userPwd: this.userPwd,
          email: this.email,
        })
        .then(({ data }) => {
          let msg = "회원가입 처리시 문제가 발생했습니다.";
          if (data === "success") {
            msg = "회원가입이 완료되었습니다.";
          }
          alert(msg);
          this.$router.push({ name: "SignIn" });
        });
    },
  },
};
</script>

<style scoped>
* {
  margin: 0;
  padding: 0;
  font-family: sans-serif;
}
.wrap {
  height: 100%;
  width: 100%;
  background-position: center;
  background-size: cover;
  position: absolute;
  background-image: url("~@/assets/img/house1.jpg");
}
.form-wrap {
  width: 380px;
  height: 560px;
  position: relative;
  margin: 6% auto;
  padding: 40px;
  background: #f7f6f2;
  overflow: hidden;
}
.togglebtn {
  padding: 10px 25px;
  cursor: pointer;
  background: linear-gradient(to right, #82ae46, #faca6a);
  border-radius: 30px;
  border: 0;
  outline: none;
  position: relative;
  color: white;
}
form {
  margin-top: 20px;
}
#pwdfind {
  text-align: left;
  font-size: 2px;
  font-style: italic;
  color: #777;
  font: italic bold;
}
.input-group {
  top: 100px;
  position: absolute;
  width: 280px;
  transition: 0.5s;
}
.input-field {
  width: 100%;
  padding: 10px 0;
  margin: 10px 0;
  border: none;
  border-bottom: 1px solid #999;
  outline: none;
  background: transparent;
}
.under-btn {
  width: 45%;
  padding: 10px 30px;
  cursor: pointer;
  display: block;
  margin: auto;
  background: linear-gradient(to right, #03c273, #faca6a);
  border: 0;
  outline: none;
  border-radius: 30px;
}
#resetBtn {
  background: white;
}
</style>
