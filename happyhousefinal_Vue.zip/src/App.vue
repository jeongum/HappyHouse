<template>
  <div id="app">
    <navi />
    <router-view/>
  </div>
</template>

<script>
import Navi from "@/components/common/Nav";

export default {
  components:{
    Navi
  }
};
</script>

<style>
*{
  font-family: "Poppins", Arial, sans-serif;
}
a{
  color: unset !important;
  text-decoration: unset !important;
  transition: .3s all ease;
}
a:hover, a:focus{
  color: unset !important;
  text-decoration: unset !important;
}
</style>
