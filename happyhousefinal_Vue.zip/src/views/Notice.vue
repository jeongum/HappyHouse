<template>
    <router-view></router-view>
</template>

<script>
export default {
  name: "Notice",
};
</script>

<style scoped></style>
