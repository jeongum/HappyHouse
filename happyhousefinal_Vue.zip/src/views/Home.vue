<template>
  <div>
    <section>
      <carousel :autoplay="true" :nav="false" :items="1" :dots="false">
        <div>
          <div class="textoverlay">
            <h1>Find your HappyHouse</h1>
            <p class="subheading">
              관심지역을 등록하고 최고의 집을 찾아보세요!
            </p>
            <p>
              <a href="#favorite" class="btn btn-primary rounded-pill"
                >관심지역 등록</a
              >
            </p>
          </div>
          <img src="@/assets/img/house1.jpg" />
        </div>
        <div>
          <div class="textoverlay">
            <h1>Enjoy your HappyHouse</h1>
            <p class="subheading">관심지역의 다양한 정보를 확인하세요!</p>
            <p>
              <a href="#favorite" class="btn btn-primary rounded-pill"
                >관심지역 등록</a
              >
            </p>
          </div>
          <img src="@/assets/img/house2.jpg" />
        </div>
        <div>
          <div class="textoverlay">
            <h1>Take Care of your Health</h1>
            <p class="subheading">관심지역의 건강 정보를 확인하세요!</p>
            <p>
              <a href="#favorite" class="btn btn-primary rounded-pill"
                >관심지역 등록</a
              >
            </p>
          </div>
          <img src="@/assets/img/house3.jpg" />
        </div>
      </carousel>
    </section>
    <section id="favorite">
      <b-container>
        <b-row
          class="mt-4 mb-4 text-center justify-content-center"
          v-if="userInfo"
        >
          <h2 style="font-weight: 800">
            현재
            <span style="font-size: 2.3rem; color: #82ae46">{{
              userInfo.userName
            }}</span
            >님의
            <span v-if="sido.name">
              관심지역은
              <span style="font-size: 2.3rem; color: #82ae46"
                >{{ sido.name }} {{ gugun.name }}</span
              >
              입니다.
            </span>
            <span v-else>등록된 관심지역이 없습니다.</span>
          </h2>
        </b-row>
        <b-row class="mt-4 mb-4 text-center justify-content-center" v-else>
          <h2 style="font-weight: 800">등록된 관심지역이 없습니다.</h2>
        </b-row>
        <b-form @submit="onSubmit">
          <b-row class="mt-4 mb-4 text-center">
            <b-col class="sm-3">
              <b-form-select
                v-model="sidoCode"
                :options="sidos"
                @change="gugunList"
              ></b-form-select>
            </b-col>
            <b-col class="sm-3">
              <b-form-select
                v-model="gugunCode"
                :options="guguns"
              ></b-form-select>
            </b-col>
            <b-col cols="2">
              <b-button pill type="submit" v-if="userInfo">수정하기</b-button>
              <b-button pill type="submit" v-else>등록하기</b-button>
            </b-col>
          </b-row>
        </b-form>
      </b-container>
    </section>
    <section class="bg-light" id="info">
      <b-container>
        <b-row class="text-center">
          <b-col>
            <div>
              <b-icon
                icon="building"
                class="rounded-circle p-4"
                variant="light"
                style="background: #e4b2d6; width: 100px; height: 100px"
              ></b-icon>
            </div>
            <div>
              <h3 class="heading">실시간 주택 거래가</h3>
              <span
                >관심 지역으로 설정한 지역의<br />실시간 거래 정보를 확인할 수
                있습니다!</span
              >
            </div>
          </b-col>
          <b-col>
            <div>
              <b-icon
                icon="bar-chart-line"
                class="rounded-circle p-4"
                variant="light"
                style="background: #dcc698; width: 100px; height: 100px"
              ></b-icon>
            </div>
            <div>
              <h3 class="heading">주택 주변 환경</h3>
              <span
                >관심 주택 주변의 실거래 가격 지수,<br />주변 상가 정보등을<br />한눈에
                파악 할 수 있습니다.</span
              >
            </div>
          </b-col>
          <b-col>
            <div>
              <b-icon
                icon="bicycle"
                class="rounded-circle p-4"
                variant="light"
                style="background: #a2d1e1; width: 100px; height: 100px"
              ></b-icon>
            </div>
            <div>
              <h3 class="heading">지역 건강 시설</h3>
              <span
                >관심 지역에서 건강을 챙겨보세요!<br />공공체육시설 정보와
                따릉이 정보를 알 수 있습니다.</span
              >
            </div>
          </b-col>
        </b-row>
      </b-container>
    </section>
    <footer class="section">
      <b-container>
        <b-row class="mb-5">
          <b-col>
            <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">Happyhouse</h2>
              <p>
                Mid pleasures and palaces though we may roam, Be it ever so
                humble, there's no place like home.
              </p>
            </div>
          </b-col>
          <b-col>
            <div class="ftco-footer-widget mb-4 ml-md-5">
              <h2 class="ftco-heading-2">Menu</h2>
              <ul class="list-unstyled">
                <li><a href="#" class="py-2 d-block">거래정보</a></li>
                <li><a href="#" class="py-2 d-block">동네정보</a></li>
                <li><a href="#" class="py-2 d-block">게시판</a></li>
                <li><a href="#" class="py-2 d-block">마이페이지</a></li>
              </ul>
            </div>
          </b-col>
          <b-col>
            <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">Help</h2>
              <div class="d-flex">
                <ul class="list-unstyled mr-l-5 pr-l-3 mr-4">
                  <li>
                    <a href="#" class="py-2 d-block">Terms &amp; Conditions</a>
                  </li>
                  <li><a href="#" class="py-2 d-block">Privacy Policy</a></li>
                </ul>
                <ul class="list-unstyled">
                  <li><a href="#" class="py-2 d-block">FAQs</a></li>
                  <li><a href="#" class="py-2 d-block">Contact</a></li>
                </ul>
              </div>
            </div>
          </b-col>
          <b-col>
            <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">Have a Questions?</h2>
              <div class="block-23 mb-3">
                <ul>
                  <li>
                    <span class="icon icon-map-marker"></span
                    ><span class="text"
                      >서울시 강남구 테헤란로 212 멀티캠퍼스, SSAFY</span
                    >
                  </li>
                  <li>
                    <a href="#"
                      ><span class="icon icon-phone"></span
                      ><span class="text">+10 1234 1234</span></a
                    >
                  </li>
                  <li>
                    <a href="#"
                      ><span class="icon icon-envelope"></span
                      ><span class="text">ssafy@ssafy.com</span></a
                    >
                  </li>
                </ul>
              </div>
            </div>
          </b-col>
        </b-row>
        <b-row class="row">
          <div class="col-md-12 text-center">
            <p>Copyright &copy;2021 All rights reserved</p>
          </div>
        </b-row>
      </b-container>
    </footer>
  </div>
</template>

<script>
import { mapState, mapActions, mapMutations } from "vuex";
import http from "@/util/http-common";
import carousel from "vue-owl-carousel";

const memberStore = "memberStore";

export default {
  name: "Home",
  components: { carousel },
  data() {
    return {
      sidoCode: null,
      gugunCode: null,
      sidoName: null,
      gugunName: null,
    };
  },
  computed: {
    ...mapState(["sidos", "guguns", "houses", "sido", "gugun"]),
    ...mapState(memberStore, ["isLogin", "userInfo"]),
  },
  created() {
    this.CLEAR_SIDO_LIST();
    this.getSido();
    this.getSportInfos();
    this.getBicycles();
  },
  methods: {
    ...mapActions([
      "getSido",
      "getGugun",
      "getAptRealPrc",
      "getFavorite",
      "getSportInfos",
      "getBicycles",
    ]),
    ...mapMutations(["CLEAR_SIDO_LIST", "CLEAR_GUGUN_LIST"]),
    gugunList() {
      this.CLEAR_GUGUN_LIST();
      this.gugunCode = null;
      if (this.sidoCode) {
        this.getGugun(this.sidoCode);
        this.getAptRealPrc(this.sidoCode);
      }
    },
    onSubmit(event) {
      event.preventDefault();
      if (this.userInfo) {
        const params = {
          userid: this.userInfo.userId,
          sido: this.sidoCode,
          gugun: this.gugunCode,
        };
        http.get("/user/favorite", { params }).then(({ data }) => {
          let msg = "등록 처리시 문제가 발생했습니다.";
          if (data === "success") {
            this.getFavorite([this.sidoCode, this.gugunCode]);
            msg = "등록이 완료되었습니다.";
          }
          alert(msg);
        });
      } else {
        alert("로그인 후 등록해주세요!");
        this.$router.push({ name: "SignIn" });
      }
    },
  },
};
</script>
<style>
@import url("https://fonts.googleapis.com/css2?family=Amatic+SC&display=swap");
* {
  scroll-behavior: smooth;
}
.owl-carousel.owl-loaded {
  height: 650px;
}
.owl-stage-outer {
  height: 100%;
  width: 100%;
}

.owl-carousel > div {
  display: inline-block;
  background-color: transparent;
  overflow: hidden;
}

.owl-carousel div h2,
.owl-carousel div .textoverlay {
  width: 100%;
  top: 15%;
  text-align: center;
  justify-content: center;
  position: absolute;
  display: block;
}

.owl-carousel div h2,
.owl-carousel div .textoverlay h1 {
  font-size: 8vw;
  color: #fff;
  line-height: 1.3;
  font-weight: 600;
  font-family: "Amatic SC", cursive;
  text-align: center;
}

.owl-carousel div h2,
.owl-carousel div .textoverlay .subheading {
  font-weight: 500;
  font-size: 16px;
  letter-spacing: 4px;
  text-transform: uppercase;
  display: inline-block;
  color: #fff;
}

.btn.btn-primary {
  background: #82ae46;
  border: 3px solid #82ae46;
  color: #fff !important;
}

.btn.btn-primary:focus,
.btn.btn-primary:hover {
  background: transparent;
  border: 3px solid #82ae46;
  color: #fff !important;
}

#favorite {
  margin: 10rem 0;
}
#favorite form {
  padding: 1.5rem;
  border: 1px solid rgba(0, 0, 0, 0.1);
}
#info {
  padding: 5rem 0;
  background-color: #f7f6f2 !important;
}
#info h3 {
  margin-top: 1rem;
  font-size: 15px;
  text-transform: uppercase;
  font-weight: 500;
  font-family: "Poppins", Arial, sans-serif;
  color: #000000;
}
#info span {
  text-transform: uppercase;
  color: rgba(0, 0, 0, 0.5);
  font-size: 12px;
  font-weight: 500;
}
footer {
  font-size: 14px;
  padding: 7em 0;
  color: #000000;
}
footer .ftco-footer-widget h2 {
  font-weight: normal;
  margin-bottom: 20px;
  font-size: 16px;
  font-weight: 500;
}
</style>
