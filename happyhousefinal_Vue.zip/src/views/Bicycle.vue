<template>
  <router-view />
</template>
<script>
import { mapActions } from "vuex";


export default{
  created() {
    this.getBicycles();
  },
  methods: {
    ...mapActions(["getBicycles"])
  },
}
</script>
