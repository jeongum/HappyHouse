import Vue from "vue";
import Vuex from "vuex";
import http from "@/util/http-common";
import axios from "axios";
Vue.use(Vuex);
import memberStore from "@/store/modules/memberStore.js";

export default new Vuex.Store({
  modules: {
    memberStore,
  },
  state: {
    /* ------------ QNA STATE ------------ */
    qnas: [],
    qna: {},
    answers: [],

    /* ------------ HOUSE STATE ------------ */
    sidos: [{ value: null, text: "시.도" }],
    sido: {},
    guguns: [{ value: null, text: "구.군" }],
    gugun: {},
    houses: [],
    house: null,
    aptRealPrcs: [],

    /* ------------ STORE STATE ------------ */
    stores: [],

    /* ------------ Health STATE ------------ */
    bicycles: [],
    sportinfos: [],
  },
  getters: {
    qnas(state) {
      return state.qnas;
    },
    qna(state) {
      return state.qna;
    },
    answers(state) {
      return state.answers;
    },
  },
  mutations: {
    /* ------------ QNA MUTAT ------------ */
    SET_QNAS(state, payload) {
      state.qnas = payload;
    },
    SET_QNA(state, payload) {
      state.qna = payload;
    },
    SET_ANSWERS(state, payload) {
      state.answers = payload;
    },

    /* ------------ HOUSE MUTAT ------------ */
    SET_SIDO_LIST(state, sidos) {
      sidos.forEach((sido) => {
        state.sidos.push({ value: sido.sidoCode, text: sido.sidoName });
      });
    },
    SET_SIDO(state, payload) {
     state.sido = {code: payload[1], name:payload[0]};
    },
    SET_GUGUN_LIST(state, guguns) {
      guguns.forEach((gugun) => {
        state.guguns.push({ value: gugun.gugunCode, text: gugun.gugunName });
      });
    },
    SET_GUGUN(state, payload) {
      state.gugun = {code: payload[1], name:payload[0]};
    },
    CLEAR_SIDO_LIST(state) {
      state.sidos = [{ value: null, text: "시.도" }];
    },
    CLEAR_GUGUN_LIST(state) {
      state.guguns = [{ value: null, text: "구.군" }];
    },
    SET_HOUSE_LIST(state, houses) {
      state.houses = houses;
    },
    SET_DETAIL_HOUSE(state, house) {
      state.house = house;
    },
    SET_APTREALPRC_LIST(state, aptRealPrcs) {
      state.aptRealPrcs = aptRealPrcs;
    },

    /* ------------ STORE MUTAT ------------ */
    SET_STORE_LIST(state, stores) {
      state.stores = stores;
    },

    /* ------------ Health MUTAT ------------ */
    SET_BICYCLE_LIST(state, bicycles){
      state.bicycles = bicycles;
    },
    SET_SPORT_INFOS(state, payload){
      state.sportinfos = payload;
    },
  },
  actions: {
    /* ------------ QNA ACTIONS ------------ */
    getQnAs(context) {
      http
        .get("/question")
        .then(({ data }) => {
          context.commit("SET_QNAS", data);
        })
        .catch(() => {
          alert("질문목록: 에러발생!");
        });
    },
    getQnA({ commit }, payload) {
      http
        .get("/question/" + payload)
        .then(({ data }) => {
          commit("SET_QNA", data);
        })
        .catch(() => {
          alert("질문조회: 에러발생!");
        });
    },
    getAnswers({ commit }, payload) {
      http
        .get("/answer/" + payload)
        .then(({ data }) => {
          commit("SET_ANSWERS", data);
        })
        .catch(() => {
          alert("댓글조회: 에러발생!");
        });
    },

    /* ------------ HOUSE ACTIONS ------------ */
    getSido({ commit }) {
      http
        .get(`/map/sido`)
        .then((response) => {
          commit("SET_SIDO_LIST", response.data);
        })
        .catch((error) => {
          console.log(error);
        });
    },
    getGugun({ commit }, sidoCode) {
      const params = { sido: sidoCode };
      http
        .get(`/map/gugun`, { params })
        .then((response) => {
          commit("SET_GUGUN_LIST", response.data);
        })
        .catch((error) => {
          console.log(error);
        });
    },
    getAptRealPrc({ commit }, sidoCode) {
      const params = { sido: sidoCode };
      http
        .get(`/housedetail/realprc`, { params })
        .then((response) => {
          commit("SET_APTREALPRC_LIST", response.data);
        })
        .catch((error) => {
          console.log(error);
        });
    },
    getHouseList({ commit }, gugunCode) {
      const params = { gugunCode: gugunCode};
      http
        .get(`/map/apt`, { params })
        .then((response) => {
          commit("SET_HOUSE_LIST", response.data.response.body.items.item);
        })
        .catch((error) => {
          console.log(error);
        });
    },
    detailHouse({ commit }, house) {
      commit("SET_DETAIL_HOUSE", house);
    },
    /* ------------ STORE ACTIONS ------------ */
    getStoreList({ commit }, payload) {
      const params = { cx: payload[0], cy: payload[1]};
      http
        .get(`/housedetail/store`, { params })
        .then((response) => {
          commit("SET_STORE_LIST", response.data.body.items);
        })
        .catch((error) => {
          console.log(error);
        });
    },

    /* ------------ Health ACTIONS ------------ */
    getBicycles({commit}){
      http
        .get(`/bicycle/list`)
        .then((response) => {
          commit("SET_BICYCLE_LIST", response.data);
        });
    },

    getSportInfos({commit}){
      axios
      .get(
        "http://openAPI.seoul.go.kr:8088/4243796c7062796837374379665370/json/ListPublicReservationSport/1/400/"
      )
      .then(
        function (response) {
          commit("SET_SPORT_INFOS", response.data.ListPublicReservationSport.row);
        }
      )
    },

    getFavorite({commit}, payload){
      const params = {sido: payload[0], gugun: payload[1]};
      http
        .get('/map/favoriteName', {params})
        .then(({data})=>{
          commit("SET_SIDO", [data[0], payload[0]]);
          commit("SET_GUGUN", [data[1], payload[1]]);
        });
    }
  },
});
