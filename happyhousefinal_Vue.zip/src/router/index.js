import Vue from "vue";
import VueRouter from "vue-router";
import Home from "../views/Home.vue";
import QNA from "../views/QnA.vue";
import House from "@/views/House.vue";
import Bicycle from "@/views/Bicycle.vue";

import store from "@/store/index.js";

import Member from "@/views/Member.vue";
import Notice from "@/views/Notice.vue";

import SportsFacility from "@/views/SportsFacility.vue";
Vue.use(VueRouter);
// https://router.vuejs.org/kr/guide/advanced/navigation-guards.html
const onlyAuthUser = async (to, from, next) => {
  const checkUserInfo = store.getters["memberStore/checkUserInfo"];
  const getUserInfo = store._actions["memberStore/getUserInfo"];
  let token = sessionStorage.getItem("access-token");
  if (checkUserInfo == null && token) {
    await getUserInfo(token);
  }
  if (checkUserInfo === null) {
    alert("로그인이 필요한 페이지입니다..");
    // next({ name: "SignIn" });
    router.push({ name: "SignIn" });
  } else {
    next();
  }
};

const routes = [
  {
    path: "/",
    name: "Home",
    component: Home,
  },
  {
    path: "/qna",
    name: "QNA",
    component: QNA,
    redirect: "/qna/list",
    children: [
      {
        path: "list",
        name: "QnAList",
        component: () => import("../components/qna/QnAList.vue"),
      },
      {
        path: "create",
        name: "QnACreate",
        beforeEnter: onlyAuthUser,
        component: () => import("../components/qna/QnACreate.vue"),
      },
      {
        path: "view/:question_no",
        name: "QnAView",
        beforeEnter: onlyAuthUser,
        component: () => import("../components/qna/QnAView.vue"),
      },
      {
        path: "modify/:question_no",
        name: "QnAModify",
        beforeEnter: onlyAuthUser,
        component: () => import("../components/qna/QnAModify.vue"),
      },
    ],
  },
  {
    path: "/user",
    name: "Member",
    component: Member,
    children: [
      {
        path: "singin",
        name: "SignIn",
        component: () => import("@/components/user/MemberLogin.vue"),
      },
      {
        path: "singup",
        name: "SignUp",
        component: () => import("@/components/user/MemberJoin.vue"),
      },
      {
        path: "mypage",
        name: "MyPage",
        beforeEnter: onlyAuthUser,
        component: () => import("@/components/user/MemberMyPage.vue"),
      },
      {
        path: "update/:userId",
        name: "UserUpdate",
        beforeEnter: onlyAuthUser,
        component: () => import("@/components/user/MemberUpdate.vue"),
      },
      {
        path: "findpwd",
        name: "FindPwd",
        component: () => import("@/components/user/FindPwd.vue"),
      },
    ],
  },
  {
    path: "/house",
    name: "House",
    component: House,
    beforeEnter: onlyAuthUser,
    redirect: "/house/list",
    children: [
      {
        path: "list",
        name: "HouseList",
        component: () => import("../components/house/HouseList.vue"),
      },
      {
        path: "detail",
        name: "HouseDetail",
        component: () => import("../components/house/HouseDetail.vue"),
      },
    ],
  },
  {
    path: "/sport",
    name: "Sport",
    component: SportsFacility,
    redirect: "/sport/list",
    children: [
      {
        path: "list",
        name: "SportsFacilityList",
        beforeEnter: onlyAuthUser,
        component: () => import("../components/sport/SportsFacilityList.vue"),
      },
      {
        path: "view/:no",
        name: "SportInfoDetail",
        beforeEnter: onlyAuthUser,
        component: () => import("../components/sport/SportFacilityDetail.vue"),
      },
    ],
  },

  {
    path: "/notice",
    name: "Notice",
    component: Notice,
    redirect: "/notice/list",
    children: [
      {
        path: "list",
        name: "NoticeList",
        component: () => import("@/components/notice/NoticeList.vue"),
      },
      {
        path: "view/:noticeno",
        name: "NoticeView",
        component: () => import("../components/notice/NoticeView.vue"),
      },
      {
        path: "modify/:noticeno",
        name: "NoticeModify",
        component: () => import("../components/notice/NoticeModify.vue"),
      },
      //NoticeCreate
      {
        path: "create",
        name: "NoticeCreate",
        component: () => import("../components/notice/NoticeCreate.vue"),
      },
    ],
  },
  {
    path:"/bicycle",
    name: "Bicycle",
    beforeEnter: onlyAuthUser,
    component: Bicycle,
    redirect: "/bicycle/list",
    children: [
      {
        path: "list",
        name: "BicycleList",
        component: () => import("../components/health/BicycleList.vue"),
      },
    ]
  }
];

const router = new VueRouter({
  mode: "history",
  base: process.env.BASE_URL,
  routes,
});

export default router;
